document.addEventListener("DOMContentLoaded", () => {
  const userInput = document.getElementById("userInput");
  const btnContinuar = document.getElementById("btnContinuar");
  const codigoBox = document.getElementById("codigoBox");
  const codigoInput = document.getElementById("codigo");
  const btnConfirmar = document.getElementById("btnConfirmar");

  // Função para enviar o email e gerar o código no backend
  function enviarCodigoEmail(email) {
    return fetch("processa_form.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: "email=" + encodeURIComponent(email) + "&tipo_form=recuperar"
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert(data.message);
        return true;
      } else {
        alert(data.message);
        return false;
      }
    })
    .catch(error => {
      alert("Erro ao enviar o código: " + error);
      return false;
    });
  }

  // Etapa 1: Enviar email para recuperação
  btnContinuar.addEventListener("click", () => {
    const user = userInput.value.trim();
    if (!user) {
      alert("Digite seu Gmail!");
      userInput.focus();
      return;
    }

    enviarCodigoEmail(user).then(success => {
      if (success) {
        codigoBox.style.display = "block";  // Exibe o campo para digitar o código
        codigoInput.focus();
      }
    });
  });

  // Etapa 2: Confirmar código inserido pelo usuário
  btnConfirmar.addEventListener("click", () => {
    const codigo = codigoInput.value.trim();
    if (!codigo) {
      alert("Digite o código para continuar!");
      codigoInput.focus();
      return;
    }

    fetch("processa_form.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: "codigo=" + encodeURIComponent(codigo) + "&tipo_form=validar_codigo"
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert(data.message);
        // Redireciona automaticamente
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      } else {
        alert(data.message);
        codigoInput.focus();
      }
    })
    .catch(error => {
      alert("Erro ao validar o código: " + error);
    });
  });
});
