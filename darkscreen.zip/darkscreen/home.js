const filmesData = [
  {id: 'f1', title: 'O Sussurro na Noite', type:'filme', cover:'img/cover1.jpg', trailer:'videos/trailer1.mp4'},
  {id: 'f2', title: 'Casa das Sombras', type:'filme', cover:'img/cover2.jpg', trailer:'videos/trailer2.mp4'},
  {id: 'f3', title: 'Limiar', type:'filme', cover:'img/cover3.jpg', trailer:'videos/trailer3.mp4'},
  {id: 'f4', title: 'Ritual', type:'filme', cover:'img/cover4.jpg', trailer:'videos/trailer4.mp4'},
  {id: 's1', title: 'Noite Eterna', type:'serie', cover:'img/serie1.jpg', trailer:'videos/serie-trailer1.mp4', temporadas:3, ano:2022},
  {id: 's2', title: 'Ecos do Bosque', type:'serie', cover:'img/serie2.jpg', trailer:'videos/serie-trailer2.mp4', temporadas:2, ano:2021},
  {id: 's3', title: 'Sombras da Lua', type:'serie', cover:'img/serie3.jpg', trailer:'videos/serie-trailer3.mp4', temporadas:1, ano:2023},
  {id: 's4', title: 'Noite Sem Fim', type:'serie', cover:'img/serie4.jpg', trailer:'videos/serie-trailer4.mp4', temporadas:2, ano:2020}
];

const inicioGrid = document.getElementById('inicio-grid');
const filmesGrid = document.getElementById('filmes-grid');
const seriesGrid = document.getElementById('series-grid');
const favoritosGrid = document.getElementById('favoritos-grid');
const searchInput = document.getElementById('search');
const navBtns = document.querySelectorAll('.nav-btn');
const trailerModal = document.getElementById('trailer-modal');
const trailerVideo = document.getElementById('trailer-video');
const closeModalBtn = document.getElementById('close-modal');

function getFavs(){try{return JSON.parse(localStorage.getItem('ds_favs')||'[]')}catch(e){return []}}
function saveFavs(arr){localStorage.setItem('ds_favs',JSON.stringify(arr))}

function createCard(item){
  const card=document.createElement('div'); card.className='card'; card.dataset.id=item.id;
  card.innerHTML=`
    <img src="${item.cover}" alt="${item.title}">
    <h3>${item.title}</h3>
    <div class="meta">${item.type==='filme'?'Filme':'Série'}</div>
    <div class="actions">
      <button class="btn btn-fav" data-id="${item.id}">${getFavs().includes(item.id)?'✓ Favorito':'♡ Favoritar'}</button>
      <button class="btn primary btn-trailer" data-trailer="${item.trailer}">Assistir Trailer</button>
    </div>
  `;
  return card;
}

function renderAll(){
  inicioGrid.innerHTML=''; filmesGrid.innerHTML=''; seriesGrid.innerHTML=''; favoritosGrid.innerHTML='';
  const favs=getFavs();
  filmesData.forEach(it=>{
    const card=createCard(it);
    inicioGrid.appendChild(card.cloneNode(true));
    if(it.type==='filme') filmesGrid.appendChild(card.cloneNode(true));
    else seriesGrid.appendChild(card.cloneNode(true));
  });
  favs.forEach(id=>{
    const item=filmesData.find(x=>x.id===id);
    if(item) favoritosGrid.appendChild(createCard(item));
  });
}

document.addEventListener('click',(e)=>{
  if(e.target.matches('.btn-fav')){
    const id=e.target.dataset.id;
    let favs=getFavs();
    if(favs.includes(id)){ favs=favs.filter(x=>x!==id); e.target.textContent='♡ Favoritar'; }
    else{ favs.push(id); e.target.textContent='✓ Favorito'; }
    saveFavs(favs); renderAll();
  }
  if(e.target.matches('.btn-trailer')){
    const src=e.target.dataset.trailer; openTrailer(src);
  }
});

function openTrailer(src){
  trailerVideo.src=src;
  trailerModal.classList.remove('hidden');
  trailerVideo.play().catch(()=>{});
}
closeModalBtn.addEventListener('click',()=>{closeTrailer();});
function closeTrailer(){
  trailerVideo.pause(); trailerVideo.currentTime=0; trailerVideo.src='';
  trailerModal.classList.add('hidden');
}
trailerVideo.addEventListener('ended',()=>{closeTrailer();});

searchInput.addEventListener('input',()=>{const q=searchInput.value.trim().toLowerCase(); filterByQuery(q);});
function filterByQuery(q){document.querySelectorAll('.grid .card').forEach(card=>{const title=card.querySelector('h3').textContent.toLowerCase(); card.style.display=!q||title.includes(q)?'flex':'none';});}

navBtns.forEach(btn=>btn.addEventListener('click',()=>{
  navBtns.forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const target=btn.dataset.target;
  document.querySelectorAll('.content-section').forEach(sec=>sec.classList.add('hidden'));
  document.getElementById(target).classList.remove('hidden');
}));

// --- CARROSSEL ---
const slides=document.querySelectorAll('.slide');
let current=0;
function goTo(i){
  slides[current].classList.remove('active');
  current=(i+slides.length)%slides.length;
  slides[current].classList.add('active');
}
setInterval(()=>goTo(current+1),3000);

renderAll();