$(function(){

// Navegação entre seções
$('.sidebar a[data-section]').click(function(e){
    e.preventDefault();
    const target = $(this).data('section');
    $('.sidebar a').removeClass('active');
    $(this).addClass('active');
    $('.section').removeClass('active');
    $('#' + target).addClass('active');
});

// Upload foto
$('#upload-icon').on('change', function(){
    const formData = new FormData();
    formData.append('tipo_form','foto');
    formData.append('foto', this.files[0]);
    $.ajax({
        url:'processa_form.php',
        type:'POST',
        data:formData,
        processData:false,
        contentType:false,
        dataType:'json',
        success:function(res){
            if(res.success) $('#profile-icon').attr('src',res.foto);
            else alert(res.message || 'Erro ao enviar imagem.');
        }
    });
});

// Atualizar usuário
$('#usuario-form').submit(function(e){
    e.preventDefault();
    const dados = $(this).serialize() + '&tipo_form=atualizar_usuario';
    $.post('processa_form.php', dados, function(res){
        if(res.success) alert('Dados atualizados!');
        else alert(res.message||'Erro ao atualizar usuário.');
    },'json');
});

// Atualizar preferências
$('#preferencias-form').submit(function(e){
    e.preventDefault();
    const dados = $(this).serialize() + '&tipo_form=preferencias';
    $.post('processa_form.php', dados, function(res){
        if(res.success) alert('Preferências salvas!');
        else alert(res.message||'Erro ao salvar preferências.');
    },'json');
});

// Conectar / desconectar dispositivo
$('.btn-dispositivo').click(function(){
    const btn=$(this);
    const id=btn.data('id');
    const acao=btn.text().trim().toLowerCase();
    $.post('processa_form.php',{tipo_form:'dispositivo',id:id,acao:acao},function(res){
        if(res.success) btn.text(res.novo_estado?'Desconectar':'Conectar');
        else alert(res.message||'Erro ao atualizar dispositivo.');
    },'json');
});

});
