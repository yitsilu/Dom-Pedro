<?php
session_start();

// Verifica se usuário está logado
if(!isset($_SESSION['usuario'])){
    header("Location: index.html");
    exit;
}

// Recebe o plano selecionado via GET
$plano_param = $_GET['plano'] ?? 'padrao';

$planos = [
    'padrao' => ['id'=>1,'nome'=>'Padrão','preco'=>'19.90'],
    'premium' => ['id'=>2,'nome'=>'Premium','preco'=>'26.90'],
    'anual' => ['id'=>3,'nome'=>'Anual','preco'=>'260.00']
];

$plano = $planos[$plano_param] ?? $planos['padrao'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pagamento - DarkScreen</title>
<link rel="stylesheet" href="style.css">
<style>
    .card-row { display:flex; gap:10px; margin-bottom:15px; }
    .card-row input { flex:1; }
    .error { color:#d9534f; font-size:0.9rem; display:none; margin-top:5px; }
    .login-box { max-width:400px; margin:60px auto; padding:30px; background:#0a0a0a; border-radius:12px; box-shadow:0 0 25px rgba(155,48,255,0.7); color:#fff; }
    .btn { display:block; width:100%; padding:12px; background:#6a0dad; border:none; color:#fff; border-radius:8px; font-weight:bold; cursor:pointer; margin-top:15px; }
    .btn:hover { background:#9b30ff; }
    h2 { text-align:center; margin-bottom:20px; color:#9b30ff; text-shadow:0 0 10px #6a0dad; }
    a { color:#9b30ff; text-decoration:none; }
    a:hover { text-decoration:underline; }
    label { display:block; margin-top:12px; margin-bottom:6px; }
    input { width:100%; padding:10px; border-radius:6px; border:1px solid #4d004d; background:#1a1a1a; color:#fff; }
</style>
</head>
<body class="login-dark">
<div class="login-box">
    <h2>Pagamento - Plano <?= htmlspecialchars($plano['nome']) ?> (R$ <?= $plano['preco'] ?>)</h2>

    <form id="pagamento-form" method="POST" autocomplete="off" novalidate>
        <input type="hidden" name="tipo_form" value="pagamento">
        <input type="hidden" name="plano_id" value="<?= $plano['id'] ?>">

        <label for="card_number">Número do Cartão</label>
        <input id="card_number" name="card_number" type="text" placeholder="Ex: 4242424242424242" maxlength="19" required>
        <div id="card_number_error" class="error">Digite apenas números (13–19 dígitos).</div>

        <label for="card_name">Nome no Cartão</label>
        <input id="card_name" name="card_name" type="text" placeholder="Nome impresso no cartão" required>

        <div class="card-row">
            <div>
                <label for="card_exp">Validade (MM/AA)</label>
                <input id="card_exp" name="card_exp" type="text" placeholder="MM/AA" maxlength="5" required>
                <div id="card_exp_error" class="error">Formato: MM/AA</div>
            </div>
            <div>
                <label for="card_cvv">CVV</label>
                <input id="card_cvv" name="card_cvv" type="text" maxlength="4" placeholder="123" required>
                <div id="card_cvv_error" class="error">Digite 3 ou 4 números.</div>
            </div>
        </div>

        <button type="submit" class="btn">Finalizar Pagamento</button>
    </form>

    <p style="text-align:center; margin-top:15px;"><a href="planos.html">Voltar para planos</a></p>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(function(){
    function onlyDigits(input){ input.value = input.value.replace(/\D/g,''); }

    $('#card_number, #card_cvv').on('input', function(){ onlyDigits(this); });

    $('#card_exp').on('input', function(){
        let v = this.value.replace(/\D/g,'').slice(0,4);
        if(v.length >= 3) v = v.slice(0,2)+'/'+v.slice(2);
        this.value = v;
    });

    $('#pagamento-form').on('submit', function(e){
        e.preventDefault();
        $('.error').hide();
        let valid = true;

        const cardNumber = $('#card_number').val().trim();
        const cardName = $('#card_name').val().trim();
        const cardExp = $('#card_exp').val().trim();
        const cardCvv = $('#card_cvv').val().trim();

        if(!/^\d{13,19}$/.test(cardNumber)){ $('#card_number_error').show(); valid=false; }
        if(cardName===''){ alert('Preencha o nome no cartão'); valid=false; }

        const expRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
        if(!expRegex.test(cardExp)){ $('#card_exp_error').text('Formato MM/AA').show(); valid=false; }
        else{
            const parts = cardExp.split('/');
            const month = parseInt(parts[0],10);
            const year = parseInt('20'+parts[1],10);
            const lastDay = new Date(year, month,0);
            if(lastDay < new Date()){ $('#card_exp_error').text('Cartão expirado').show(); valid=false; }
        }

        if(!/^\d{3,4}$/.test(cardCvv)){ $('#card_cvv_error').show(); valid=false; }

        if(!valid) return;

        // Envia via AJAX
        $.post('processa_form.php', $(this).serialize(), function(res){
            if(res.success){ window.location.href = res.redirect; }
            else{ alert(res.message); }
        },'json');
    });
});
</script>
</body>
</html>
