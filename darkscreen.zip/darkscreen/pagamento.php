<?php
session_start();

// Verifica se usuário está logado
if(!isset($_SESSION['usuario'])){
    header("Location: index.html");
    exit;
}

// Recebe o plano selecionado
$plano_id = $_GET['plano_id'] ?? 1; // 1 = padrão
$planos = [
    1 => ['nome'=>'padrao','preco'=>'19.90'],
    2 => ['nome'=>'premium','preco'=>'26.90'],
    3 => ['nome'=>'anual','preco'=>'260.00']
];

$plano = $planos[$plano_id] ?? $planos[1];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pagamento - DarkScreen</title>
<link rel="stylesheet" href="style.css">
<style>
    .card-row { display:flex; gap:10px; margin-bottom:15px; }
    .card-row input { flex:1; }
    .error { color:#d9534f; font-size:0.9rem; display:none; margin-top:5px; }
</style>
</head>
<body class="login-dark">
<div class="login-box">
    <h2>Pagamento - Plano <?= htmlspecialchars($plano['nome']) ?> (R$ <?= $plano['preco'] ?>)</h2>

    <form id="pagamento-form" method="POST" autocomplete="off" novalidate>
        <input type="hidden" name="tipo_form" value="pagamento">
        <input type="hidden" name="plano_id" value="<?= $plano_id ?>">

        <label for="card_number">Número do Cartão</label>
        <input id="card_number" name="card_number" type="text" placeholder="Ex: 4242424242424242" maxlength="19" required>
        <div id="card_number_error" class="error">Digite apenas números (13–19 dígitos).</div>

        <label for="card_name">Nome no Cartão</label>
        <input id="card_name" name="card_name" type="text" placeholder="Nome impresso no cartão" required>

        <div class="card-row">
            <div>
                <label for="card_exp">Validade (MM/AA)</label>
                <input id="card_exp" name="card_exp" type="text" placeholder="MM/AA" maxlength="5" required>
                <div id="card_exp_error" class="error">Formato: MM/AA</div>
            </div>
            <div>
                <label for="card_cvv">CVV</label>
                <input id="card_cvv" name="card_cvv" type="text" maxlength="4" placeholder="123" required>
                <div id="card_cvv_error" class="error">Digite 3 ou 4 números.</div>
            </div>
        </div>

        <button type="submit" class="btn">Finalizar Pagamento</button>
    </form>

    <p><a href="planos.html">Voltar para planos</a></p>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(function(){
    function onlyDigits(input){ input.value = input.value.replace(/\D/g,''); }

    $('#card_number, #card_cvv').on('input', function(){ onlyDigits(this); });

    $('#card_exp').on('input', function(){
        let v = this.value.replace(/\D/g,'').slice(0,4);
        if(v.length >= 3) v = v.slice(0,2)+'/'+v.slice(2);
        this.value = v;
    });

    $('#pagamento-form').on('submit', function(e){
        e.preventDefault();
        $('.error').hide();
        let valid = true;

        const cardNumber = $('#card_number').val().trim();
        const cardName = $('#card_name').val().trim();
        const cardExp = $('#card_exp').val().trim();
        const cardCvv = $('#card_cvv').val().trim();

        if(!/^\d{13,19}$/.test(cardNumber)){ $('#card_number_error').show(); valid=false; }
        if(cardName===''){ alert('Preencha o nome no cartão'); valid=false; }

        const expRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
        if(!expRegex.test(cardExp)){ $('#card_exp_error').text('Formato MM/AA').show(); valid=false; }
        else{
            const parts = cardExp.split('/');
            const month = parseInt(parts[0],10);
            const year = parseInt('20'+parts[1],10);
            const lastDay = new Date(year, month,0);
            if(lastDay < new Date()){ $('#card_exp_error').text('Cartão expirado').show(); valid=false; }
        }

        if(!/^\d{3,4}$/.test(cardCvv)){ $('#card_cvv_error').show(); valid=false; }

        if(!valid) return;

        // Envia via AJAX
        $.post('processa_form.php', $(this).serialize(), function(res){
            if(res.success){ window.location.href = res.redirect; }
            else{ alert(res.message); }
        },'json');
    });
});
</script>
</body>
</html>
