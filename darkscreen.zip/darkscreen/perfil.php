<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: index.html");
    exit;
}

$host = "localhost";
$dbname = "darkscreen"; 
$user = "root";
$password = "";
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Erro na conexão com o banco: " . $conn->connect_error);
}

// Buscar dados do usuário
$id = $_SESSION['usuario'];
$stmt = $conn->prepare("SELECT u.*, p.nome AS plano_nome, p.preco AS plano_preco FROM usuarios u LEFT JOIN planos p ON u.plano_id = p.id WHERE u.id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

// Buscar dispositivos
$dispositivos = [];
$stmt2 = $conn->prepare("SELECT * FROM dispositivos WHERE usuario_id=?");
$stmt2->bind_param("i", $id);
$stmt2->execute();
$resDisp = $stmt2->get_result();
while($d = $resDisp->fetch_assoc()){
    $dispositivos[] = $d;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="perfil.css">
<title>Perfil do Usuário</title>
</head>
<body>

<nav class="sidebar">
  <ul>
    <li><a href="#" class="active" data-section="usuario"><span class="icon">👤</span> Usuário</a></li>
    <li><a href="#" data-section="preferencias"><span class="icon">⚙️</span> Preferências</a></li>
    <li><a href="#" data-section="notificacoes"><span class="icon">🔔</span> Notificações</a></li>
    <li><a href="#" data-section="assinatura"><span class="icon">💳</span> Assinatura</a></li>
    <li><a href="#" data-section="dispositivos"><span class="icon">📱</span> Dispositivos</a></li>
    <li><a href="#" data-section="conf-avancadas"><span class="icon">🛠️</span> Conf. Avançadas</a></li>
    <li><a href="home.html"><span class="icon">🏠</span> Início</a></li>
    <li><a href="index.html"><span class="icon">🚪</span> Sair</a></li>
  </ul>
</nav>

<main class="main-content">
  <header class="header">
    <h1>Perfil do Usuário</h1>
  </header>

  <section id="content">

    <!-- Usuário -->
    <section id="usuario" class="section active">
      <div class="profile-panel">
        <div class="profile-image-section">
          <div class="profile-img-container" title="Clique para alterar ícone">
            <img id="profile-icon" src="<?= $usuario['foto'] ?: 'https://via.placeholder.com/100x100.png?text=User' ?>" alt="Ícone do usuário" />
            <input type="file" id="upload-icon" accept="image/*" style="display:none" />
            <span class="upload-overlay" onclick="document.getElementById('upload-icon').click();">Alterar</span>
          </div>
        </div>
        <form id="usuario-form" novalidate>
          <div class="form-group">
            <label for="nome">Nome completo</label>
            <input id="nome" name="nome" type="text" value="<?= htmlspecialchars($usuario['nome']) ?>" required />
          </div>
          <div class="form-group">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" value="<?= htmlspecialchars($usuario['email']) ?>" required />
          </div>
          <div class="form-group">
            <label for="telefone">Telefone</label>
            <input id="telefone" name="telefone" type="tel" value="<?= htmlspecialchars($usuario['telefone'] ?? '') ?>" placeholder="(00) 00000-0000" />
          </div>
          <div class="form-group">
            <label for="senha">Senha</label>
            <input id="senha" name="senha" type="password" placeholder="Digite sua senha" />
          </div>
          <button type="submit" class="btn-primary">Aplicar</button>
        </form>
      </div>
    </section>

    <!-- Preferências -->
    <section id="preferencias" class="section">
      <div class="profile-panel">
        <h2>Preferências</h2>
        <form id="preferencias-form" novalidate>
          <div class="form-group">
            <label for="idioma">Idioma</label>
            <select id="idioma" name="idioma">
              <option value="pt-br" <?= $usuario['idioma']=='pt-br'?'selected':'' ?>>Português (BR)</option>
              <option value="en-us" <?= $usuario['idioma']=='en-us'?'selected':'' ?>>English (US)</option>
              <option value="es-es" <?= $usuario['idioma']=='es-es'?'selected':'' ?>>Español (ES)</option>
            </select>
          </div>
          <div class="form-group">
            <label for="legendas">Legendas</label>
            <select id="legendas" name="legendas">
              <option value="pt-br" <?= $usuario['legendas']=='pt-br'?'selected':'' ?>>Português (BR)</option>
              <option value="en-us" <?= $usuario['legendas']=='en-us'?'selected':'' ?>>English (US)</option>
              <option value="off" <?= $usuario['legendas']=='off'?'selected':'' ?>>Desativado</option>
            </select>
          </div>
          <div class="form-group">
            <label for="cor-letra">Cor da Letra</label>
            <input type="color" id="cor-letra" name="cor_letra" value="<?= $usuario['cor_letra'] ?: '#ff2e2e' ?>" />
          </div>
          <button type="submit" class="btn-primary">Salvar Preferências</button>
        </form>
      </div>
    </section>

    <!-- Notificações -->
    <section id="notificacoes" class="section">
      <div class="profile-panel">
        <h2>Notificações</h2>
        <form id="notificacoes-form">
          <div class="form-group checkbox">
            <input type="checkbox" id="push" name="push" checked />
            <label for="push">Notificações Push</label>
          </div>
          <div class="form-group checkbox">
            <input type="checkbox" id="email-notif" name="email-notif" />
            <label for="email-notif">Notificações por E-mail</label>
          </div>
          <div class="form-group checkbox">
            <input type="checkbox" id="sms-notif" name="sms-notif" />
            <label for="sms-notif">Notificações via SMS</label>
          </div>
          <button type="submit" class="btn-primary">Salvar Notificações</button>
        </form>
      </div>
    </section>

    <!-- Assinatura -->
    <section id="assinatura" class="section">
      <div class="profile-panel">
        <h2>Assinatura</h2>
        <p>Plano atual: <?= htmlspecialchars($usuario['plano_nome'] ?? 'Padrão') ?> (R$ <?= htmlspecialchars($usuario['plano_preco'] ?? '19.90') ?>)</p>
        <div class="plans-container">
          <div class="plan-card <?= ($usuario['plano_id']==1)?'current':'' ?>">
            <h3>Básico</h3>
            <p>R$ 19,90/mês</p>
            <button <?= ($usuario['plano_id']==1)?'disabled':'' ?>>Assinar</button>
          </div>
          <div class="plan-card <?= ($usuario['plano_id']==2)?'current':'' ?>">
            <h3>Premium</h3>
            <p>R$ 26,90/mês</p>
            <button <?= ($usuario['plano_id']==2)?'disabled':'' ?>>Assinar</button>
          </div>
          <div class="plan-card <?= ($usuario['plano_id']==3)?'current':'' ?>">
            <h3>Pro Anual</h3>
            <p>R$ 260,00/ano</p>
            <button <?= ($usuario['plano_id']==3)?'disabled':'' ?>>Assinar</button>
          </div>
        </div>
      </div>
    </section>

    <!-- Dispositivos -->
    <section id="dispositivos" class="section">
      <div class="profile-panel">
        <h2>Dispositivos Conectados</h2>
        <ul class="device-list">
          <?php foreach($dispositivos as $disp): ?>
            <li>
              <?= htmlspecialchars($disp['nome']) ?> - <?= htmlspecialchars($disp['tipo']) ?>
              <button class="btn-dispositivo" data-id="<?= $disp['id'] ?>" data-ativo="<?= $disp['ativo'] ?>">
                <?= $disp['ativo'] ? 'Desconectar' : 'Conectar' ?>
              </button>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </section>

    <!-- Configurações Avançadas -->
    <section id="conf-avancadas" class="section">
      <div class="profile-panel">
        <h2>Configurações Avançadas</h2>
        <form id="avancadas-form">
          <div class="form-group">
            <label for="api-key">Chave API</label>
            <input type="text" id="api-key" name="api-key" placeholder="Sua chave API" />
          </div>
          <div class="form-group checkbox">
            <input type="checkbox" id="dev-mode" name="dev-mode" />
            <label for="dev-mode">Modo Desenvolvedor</label>
          </div>
          <button type="submit" class="btn-primary">Salvar Configurações</button>
        </form>
      </div>
    </section>

  </section>
</main>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="perfil.js"></script>
<script src="perfil-actions.js"></script>

</body>
</html>
