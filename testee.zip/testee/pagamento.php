<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.html");
    exit;
}

// -----------------------------
// Captura o plano escolhido (por nome ou id)
// -----------------------------
$planos = [
    1 => ['nome' => 'Padrão', 'preco' => '19,90', 'descricao' => 'Com anúncios', 'periodo' => 'mês'],
    2 => ['nome' => 'Premium', 'preco' => '26,90', 'descricao' => 'Sem anúncios', 'periodo' => 'mês'],
    3 => ['nome' => 'Anual', 'preco' => '260,00', 'descricao' => 'Sem anúncios', 'periodo' => 'ano']
];

if (isset($_GET['plano_id'])) {
    $plano_id = intval($_GET['plano_id']);
} elseif (isset($_GET['plano'])) {
    $plano_nome = strtolower($_GET['plano']);
    $map = ['padrao' => 1, 'premium' => 2, 'anual' => 3];
    $plano_id = $map[$plano_nome] ?? 1;
} else {
    $plano_id = 1;
}

// Garante que o ID é válido
if (!array_key_exists($plano_id, $planos)) {
    $plano_id = 1;
}

$plano = $planos[$plano_id];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pagamento - <?= htmlspecialchars($plano['nome']) ?> - R$ <?= htmlspecialchars($plano['preco']) ?> / <?= htmlspecialchars($plano['periodo']) ?></title>
  <link rel="icon" href="favicon.png" type="image/png">
  <link rel="stylesheet" href="style.css">
</head>
<body class="login-dark">

<div class="login-box">
    <h2>Pagamento - <?= htmlspecialchars($plano['nome']) ?> - R$ <?= htmlspecialchars($plano['preco']) ?> / <?= htmlspecialchars($plano['periodo']) ?></h2>
    <p><?= htmlspecialchars($plano['descricao']) ?></p>

    <form id="pagamento-form" method="POST" autocomplete="off">
      <input type="hidden" name="tipo_form" value="pagamento">
      <input type="hidden" name="plano_id" value="<?= $plano_id ?>">

      <label for="card_number">Número do Cartão</label>
      <input id="card_number" name="card_number" type="text" placeholder="Ex: 4242424242424242" maxlength="19" required>
      <div id="card_number_error" class="error" style="display:none; color:red;">Digite apenas números (13–19 dígitos).</div>

      <label for="card_name">Nome no Cartão</label>
      <input id="card_name" name="card_name" type="text" placeholder="Nome impresso no cartão" required>

      <label for="card_exp">Validade (MM/AA)</label>
      <input id="card_exp" name="card_exp" type="text" placeholder="MM/AA" maxlength="5" required>
      <div id="card_exp_error" class="error" style="display:none; color:red;">Formato: MM/AA</div>

      <label for="card_cvv">CVV</label>
      <input id="card_cvv" name="card_cvv" type="text" maxlength="4" placeholder="123" required>
      <div id="card_cvv_error" class="error" style="display:none; color:red;">Digite 3 ou 4 números.</div>

      <button type="submit" class="btn">Finalizar Pagamento</button>
    </form>

    <p><a href="planos.html">Voltar para planos</a></p>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(function(){
    function onlyDigits(el){ el.value = el.value.replace(/\D/g,''); }
    $('#card_number, #card_cvv').on('input', function(){ onlyDigits(this); });
    $('#card_exp').on('input', function(){
        let v = this.value.replace(/\D/g,'').slice(0,4);
        if(v.length >= 3) v = v.slice(0,2)+'/'+v.slice(2);
        this.value = v;
    });

    $('#pagamento-form').on('submit', function(e){
        e.preventDefault();
        $('.error').hide();
        let valid = true;

        const cardNumber = $('#card_number').val().trim();
        const cardName = $('#card_name').val().trim();
        const cardExp = $('#card_exp').val().trim();
        const cardCvv = $('#card_cvv').val().trim();

        if(!/^\d{13,19}$/.test(cardNumber)){ $('#card_number_error').show(); valid=false; }
        if(cardName===''){ alert('Preencha o nome no cartão'); valid=false; }

        const expRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
        if(!expRegex.test(cardExp)){ $('#card_exp_error').text('Formato MM/AA').show(); valid=false; }
        else {
            const [m,y] = cardExp.split('/');
            const expDate = new Date(2000 + parseInt(y), parseInt(m), 0);
            if(expDate < new Date()){ $('#card_exp_error').text('Cartão expirado').show(); valid=false; }
        }

        if(!/^\d{3,4}$/.test(cardCvv)){ $('#card_cvv_error').show(); valid=false; }

        if(!valid) return;

        $.ajax({
            url: 'processa_form.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(res){
                if(res.success){
                    window.location.href = res.redirect;
                } else {
                    alert(res.message);
                }
            },
            error: function(xhr, status, error){
                alert("Erro ao processar pagamento: " + error);
            }
        });
    });
});
</script>

</body>
</html>
