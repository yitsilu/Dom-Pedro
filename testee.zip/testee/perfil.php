<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: index.html");
    exit;
}

$host = "localhost";
$dbname = "darkscreen"; 
$user = "root";
$password = "";
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Erro na conexão com o banco: " . $conn->connect_error);
}

// Processar atualização da foto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tipo_form'])) {
    $id = $_SESSION['usuario'];
    
    if ($_POST['tipo_form'] === 'atualizar_foto') {
        $foto_url = $_POST['foto_url'];
        
        $stmt = $conn->prepare("UPDATE usuarios SET foto = ? WHERE id = ?");
        $stmt->bind_param("si", $foto_url, $id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Foto atualizada com sucesso!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao atualizar foto.']);
        }
        exit;
    }
    
    if ($_POST['tipo_form'] === 'atualizar_usuario') {
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
        $senha = $_POST['senha'];
        
        if (!empty($senha)) {
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE usuarios SET nome = ?, email = ?, telefone = ?, senha = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $nome, $email, $telefone, $senha_hash, $id);
        } else {
            $stmt = $conn->prepare("UPDATE usuarios SET nome = ?, email = ?, telefone = ? WHERE id = ?");
            $stmt->bind_param("sssi", $nome, $email, $telefone, $id);
        }
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Dados atualizados com sucesso!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao atualizar dados.']);
        }
        exit;
    }
}

// Buscar dados do usuário
$id = $_SESSION['usuario'];
$stmt = $conn->prepare("SELECT u.*, p.nome AS plano_nome, p.preco AS plano_preco FROM usuarios u LEFT JOIN planos p ON u.plano_id = p.id WHERE u.id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

// Buscar dispositivos
$dispositivos = [];
$stmt2 = $conn->prepare("SELECT * FROM dispositivos WHERE usuario_id=?");
$stmt2->bind_param("i", $id);
$stmt2->execute();
$resDisp = $stmt2->get_result();
while($d = $resDisp->fetch_assoc()){
    $dispositivos[] = $d;
}

// Adicionar dispositivos de teste se não existirem
if(empty($dispositivos)) {
    $dispositivos_teste = [
        ['id' => '1', 'nome' => 'iPhone 13 Pro', 'tipo' => 'Smartphone', 'ativo' => 1, 'ultimo_acesso' => date('Y-m-d H:i:s')],
        ['id' => '2', 'nome' => 'MacBook Pro', 'tipo' => 'Laptop', 'ativo' => 0, 'ultimo_acesso' => date('Y-m-d H:i:s', strtotime('-1 day'))]
    ];
    $dispositivos = $dispositivos_teste;
}

// Fotos pré-definidas locais
$fotos_predefinidas = [
    'img/avatar1.jpg',
    'img/avatar2.jpg', 
    'img/avatar3.jpg',
    'img/avatar4.jpg',
    'img/avatar5.jpg',
    'img/avatar6.jpg',
    'img/avatar7.jpg',
    'img/avatar8.jpg'
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="perfil.css">
<title>Perfil do Usuário</title>
</head>
<body>

<nav class="sidebar">
  <ul>
        <li><a href="home.html"><span class="icon">🏠</span> Início</a></li>
    <li><a href="#" class="active" data-section="usuario"><span class="icon">👤</span> Usuário</a></li>
    <li><a href="#" data-section="notificacoes"><span class="icon">🔔</span> Notificações</a></li>
    <li><a href="#" data-section="assinatura"><span class="icon">💳</span> Assinatura</a></li>
    <li><a href="#" data-section="dispositivos"><span class="icon">📱</span> Dispositivos</a></li>
    <li><a href="#" data-section="conf-avancadas"><span class="icon">🛠️</span> Conf. Avançadas</a></li>
    <li><a href="index.html"><span class="icon">🚪</span> Sair</a></li>
  </ul>
</nav>

<main class="main-content">
  <header class="header">
    <h1>Perfil do Usuário</h1>
  </header>

  <section id="content">

    <!-- Usuário -->
    <section id="usuario" class="section active">
      <div class="profile-panel">
        <div class="profile-image-section">
          <div class="profile-img-container" title="Clique para alterar ícone" id="profile-image-container">
            <img id="profile-icon" src="<?= !empty($usuario['foto']) ? $usuario['foto'] : 'img/default-avatar.jpg' ?>" alt="Ícone do usuário" />
            <span class="upload-overlay" onclick="openPhotoModal()">Alterar</span>
          </div>
        </div>
        <form id="usuario-form" novalidate>
          <div class="form-group">
            <label for="nome">Nome completo</label>
            <input id="nome" name="nome" type="text" value="<?= htmlspecialchars($usuario['nome']) ?>" required />
          </div>
          <div class="form-group">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" value="<?= htmlspecialchars($usuario['email']) ?>" required />
          </div>
          <div class="form-group">
            <label for="telefone">Telefone</label>
            <input id="telefone" name="telefone" type="tel" value="<?= htmlspecialchars($usuario['telefone'] ?? '') ?>" placeholder="(00) 00000-0000" />
          </div>
          <div class="form-group">
            <label for="senha">Senha</label>
            <input id="senha" name="senha" type="password" placeholder="Digite para alterar" />
          </div>
          <button type="submit" class="btn-primary">Aplicar</button>
        </form>
      </div>
    </section>

    <!-- Notificações -->
    <section id="notificacoes" class="section">
      <div class="profile-panel">
        <div class="panel-header">
          <h2>Configurações de Notificação</h2>
          <p class="panel-description">Gerencie como você deseja receber notificações</p>
        </div>
        
        <form id="notificacoes-form">
          <div class="settings-grid">
            <div class="setting-card">
              <div class="setting-header">
                <div class="setting-icon">📱</div>
                <div>
                  <h3>Notificações Push</h3>
                  <p class="setting-description">Receba notificações no navegador</p>
                </div>
              </div>
              <label class="switch">
                <input type="checkbox" id="push" name="push" checked />
                <span class="slider"></span>
              </label>
            </div>

            <div class="setting-card">
              <div class="setting-header">
                <div class="setting-icon">📧</div>
                <div>
                  <h3>Notificações por E-mail</h3>
                  <p class="setting-description">Receba notificações no e-mail</p>
                </div>
              </div>
              <label class="switch">
                <input type="checkbox" id="email-notif" name="email-notif" />
                <span class="slider"></span>
              </label>
            </div>

            <div class="setting-card">
              <div class="setting-header">
                <div class="setting-icon">🔔</div>
                <div>
                  <h3>Som de Notificação</h3>
                  <p class="setting-description">Reproduzir som nas notificações</p>
                </div>
              </div>
              <label class="switch">
                <input type="checkbox" id="som" name="som" checked />
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn-primary">Salvar Configurações</button>
            <button type="reset" class="btn-secondary">Restaurar Padrões</button>
          </div>
        </form>
      </div>
    </section>

    <!-- Assinatura -->
    <section id="assinatura" class="section">
      <div class="profile-panel">
        <h2>Assinatura</h2>
        <p>Plano atual: <?= htmlspecialchars($usuario['plano_nome'] ?? 'Padrão') ?> (R$ <?= htmlspecialchars($usuario['plano_preco'] ?? '19.90') ?>)</p>
        <div class="plans-container">
          <div class="plan-card <?= ($usuario['plano_id']==1)?'current':'' ?>">
            <h3>Básico</h3>
            <p>R$ 19,90/mês</p>
            <button <?= ($usuario['plano_id']==1)?'disabled':'' ?>>
              <?= ($usuario['plano_id']==1)?'Plano Atual':'Assinar' ?>
            </button>
          </div>
          <div class="plan-card <?= ($usuario['plano_id']==2)?'current':'' ?>">
            <h3>Premium</h3>
            <p>R$ 26,90/mês</p>
            <button <?= ($usuario['plano_id']==2)?'disabled':'' ?>>
              <?= ($usuario['plano_id']==2)?'Plano Atual':'Assinar' ?>
            </button>
          </div>
          <div class="plan-card <?= ($usuario['plano_id']==3)?'current':'' ?>">
            <h3>Pro Anual</h3>
            <p>R$ 260,00/ano</p>
            <button <?= ($usuario['plano_id']==3)?'disabled':'' ?>>
              <?= ($usuario['plano_id']==3)?'Plano Atual':'Assinar' ?>
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- Dispositivos -->
    <section id="dispositivos" class="section">
      <div class="profile-panel">
        <div class="panel-header">
          <h2>Dispositivos Conectados</h2>
          <p class="panel-description">Gerencie os dispositivos da sua conta</p>
        </div>
        
        <div class="devices-stats">
          <div class="stat-card">
            <span class="stat-number"><?= count($dispositivos) ?></span>
            <span class="stat-label">Total</span>
          </div>
          <div class="stat-card">
            <span class="stat-number"><?= count(array_filter($dispositivos, function($d) { return $d['ativo']; })) ?></span>
            <span class="stat-label">Ativos</span>
          </div>
          <div class="stat-card">
            <span class="stat-number"><?= count(array_filter($dispositivos, function($d) { return !$d['ativo']; })) ?></span>
            <span class="stat-label">Inativos</span>
          </div>
        </div>

        <div class="devices-grid">
          <?php foreach($dispositivos as $disp): ?>
            <div class="device-card <?= $disp['ativo'] ? 'active' : 'inactive' ?>">
              <div class="device-header">
                <div class="device-icon">
                  <?php 
                    $icon = '📱';
                    if(strpos(strtolower($disp['tipo']), 'laptop') !== false) $icon = '💻';
                    elseif(strpos(strtolower($disp['tipo']), 'tablet') !== false) $icon = '📟';
                    echo $icon;
                  ?>
                </div>
                <div class="device-status">
                  <div class="status-indicator <?= $disp['ativo'] ? 'online' : 'offline' ?>"></div>
                  <span class="status-text"><?= $disp['ativo'] ? 'Online' : 'Offline' ?></span>
                </div>
              </div>
              
              <div class="device-info">
                <h4><?= htmlspecialchars($disp['nome']) ?></h4>
                <p class="device-type"><?= htmlspecialchars($disp['tipo']) ?></p>
                <p class="device-last-access">
                  Último acesso: <?= date('d/m/Y H:i', strtotime($disp['ultimo_acesso'])) ?>
                </p>
              </div>
              
              <div class="device-actions">
                <button class="btn-device <?= $disp['ativo'] ? 'btn-danger' : 'btn-success' ?>" 
                        data-id="<?= $disp['id'] ?>" 
                        data-ativo="<?= $disp['ativo'] ?>">
                  <?= $disp['ativo'] ? 'Desconectar' : 'Conectar' ?>
                </button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="device-actions-global">
          <button class="btn-secondary" id="disconnect-all">Desconectar Todos</button>
          <button class="btn-primary" id="add-device">Adicionar Dispositivo</button>
        </div>
      </div>
    </section>

    <!-- Configurações Avançadas -->
    <section id="conf-avancadas" class="section">
      <div class="profile-panel">
        <div class="panel-header">
          <h2>Configurações Avançadas</h2>
          <p class="panel-description">Configurações técnicas do sistema</p>
        </div>
        
        <form id="avancadas-form">
          <div class="settings-grid">
            <div class="setting-card">
              <div class="setting-header">
                <div class="setting-icon">🌐</div>
                <div>
                  <h3>Idioma da Interface</h3>
                  <p class="setting-description">Selecione o idioma do sistema</p>
                </div>
              </div>
              <select id="idioma" name="idioma" class="select-custom">
                <option value="pt-br" selected>Português (Brasil)</option>
                <option value="en-us">English (US)</option>
                <option value="es-es">Español</option>
              </select>
            </div>

            <div class="setting-card">
              <div class="setting-header">
                <div class="setting-icon">🔑</div>
                <div>
                  <h3>Chave API</h3>
                  <p class="setting-description">Sua chave de acesso à API</p>
                </div>
              </div>
              <div class="api-key-container">
                <input type="text" id="api-key" name="api-key" placeholder="Clique em gerar" readonly />
                <button type="button" class="btn-action" id="generate-api-key">Gerar</button>
              </div>
            </div>

            <div class="setting-card">
              <div class="setting-header">
                <div class="setting-icon">🔧</div>
                <div>
                  <h3>Modo Desenvolvedor</h3>
                  <p class="setting-description">Ativar ferramentas de desenvolvimento</p>
                </div>
              </div>
              <label class="switch">
                <input type="checkbox" id="dev-mode" name="dev-mode" />
                <span class="slider"></span>
              </label>
            </div>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn-primary">Salvar Configurações</button>
            <button type="reset" class="btn-secondary">Restaurar Padrões</button>
          </div>
        </form>
      </div>
    </section>

  </section>
</main>

<!-- Modal para seleção de foto -->
<div id="photo-modal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Escolha sua foto de perfil</h3>
      <span class="close-modal">&times;</span>
    </div>
    <div class="photo-grid">
      <?php foreach($fotos_predefinidas as $index => $foto): ?>
        <div class="photo-option" data-src="<?= $foto ?>">
          <img src="<?= $foto ?>" alt="Foto <?= $index + 1 ?>" onerror="this.src='img/default-avatar.jpg'" />
          <div class="photo-checkmark">✓</div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="modal-actions">
      <button class="btn-secondary" id="cancel-photo">Cancelar</button>
      <button class="btn-primary" id="confirm-photo">Confirmar</button>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="perfil.js"></script>

</body>
</html>