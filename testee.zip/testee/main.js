document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[data-tipo]').forEach(form => {
    const errorEl = form.querySelector('.error-message');

    form.addEventListener('submit', e => {
      e.preventDefault();

      const tipo = form.dataset.tipo;
      const formData = new FormData(form);
      formData.append('tipo_form', tipo);

      fetch('processa_form.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if(data.success){
          window.location.href = data.redirect;
        } else {
          errorEl.textContent = data.message;
        }
      })
      .catch(err => {
        errorEl.textContent = "Erro: " + err;
      });
    });
  });
});
