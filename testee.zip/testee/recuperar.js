document.addEventListener("DOMContentLoaded", () => {
  const etapaEmail = document.getElementById("etapaEmail");
  const etapaCodigo = document.getElementById("etapaCodigo");
  const etapaRecuperar = document.getElementById("etapaRecuperar");

  const userInput = document.getElementById("userInput");
  const btnContinuar = document.getElementById("btnContinuar");

  const codigoInput = document.getElementById("codigo");
  const btnConfirmar = document.getElementById("btnConfirmar");

  const btnRecuperar = document.getElementById("btnRecuperar");

  // ===== Função para enviar o email e gerar código =====
  async function enviarCodigoEmail(email) {
    try {
      const response = await fetch("processa_form.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `email=${encodeURIComponent(email)}&tipo_form=recuperar`
      });

      const text = await response.text();
      if(!text) throw new Error("Resposta vazia do servidor.");
      const data = JSON.parse(text);

      if (data.success) {
        alert(data.message || "Código enviado com sucesso!");
        return true;
      } else {
        alert(data.message || "Erro ao enviar código.");
        return false;
      }
    } catch (error) {
      alert("Erro ao enviar o código: " + error);
      return false;
    }
  }

  // ===== Função para validar o código =====
  async function validarCodigo(codigo) {
    try {
      const response = await fetch("processa_form.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `codigo=${encodeURIComponent(codigo)}&tipo_form=validar_codigo`
      });

      const text = await response.text();
      if(!text) throw new Error("Resposta vazia do servidor.");
      const data = JSON.parse(text);

      if (data.success) {
        alert(data.message || "Código validado com sucesso!");
        return data.redirect || "perfil.php";
      } else {
        alert(data.message || "Código inválido!");
        return false;
      }
    } catch (error) {
      alert("Erro ao validar o código: " + error);
      return false;
    }
  }

  // ===== Etapa 1: enviar email =====
  btnContinuar.addEventListener("click", async () => {
    const email = userInput.value.trim();
    if (!email) {
      alert("Digite seu Gmail!");
      userInput.focus();
      return;
    }

    const success = await enviarCodigoEmail(email);
    if (success) {
      if(etapaEmail) etapaEmail.classList.remove("active");
      if(etapaCodigo) setTimeout(() => etapaCodigo.classList.add("active"), 200);
      if(codigoInput) codigoInput.focus();
    }
  });

  // ===== Etapa 2: validar código =====
  btnConfirmar.addEventListener("click", async () => {
    const codigo = codigoInput.value.trim();
    if (!codigo) {
      alert("Digite o código para continuar!");
      codigoInput.focus();
      return;
    }

    const redirectUrl = await validarCodigo(codigo);
    if (redirectUrl) {
      if(etapaCodigo) etapaCodigo.classList.remove("active");
      if(etapaRecuperar) setTimeout(() => etapaRecuperar.classList.add("active"), 200);
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1000); // redireciona após animação
    } else {
      codigoInput.focus();
    }
  });

  // ===== Etapa 3: botão final (caso queira deixar) =====
  btnRecuperar?.addEventListener("click", () => {
    window.location.href = "perfil.php";
  });
});
