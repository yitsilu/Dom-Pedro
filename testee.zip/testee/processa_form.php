<?php
session_start();
header("Content-Type: application/json");

// =========================
// Conexão MySQL
// =========================
$host = "localhost";
$dbname = "darkscreen"; 
$user = "root";
$password = "";
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success'=>false,'message'=>"Erro na conexão com o banco: " . $conn->connect_error]);
    exit;
}

// =========================
// Funções Gerais
// =========================

// Verifica se email já existe
function emailRegistrado($email) {
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    return $res->num_rows > 0;
}

// Cadastra usuário
function cadastrarUsuario($nome, $email, $senha, $plano_id=1) {
    global $conn;
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nome,email,senha_hash,plano_id) VALUES (?,?,?,?)");
    $stmt->bind_param("sssi",$nome,$email,$senha_hash,$plano_id);
    if($stmt->execute()){
        return $conn->insert_id;
    }
    return false;
}

// Login usuário
function loginUsuario($email,$senha){
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $res = $stmt->get_result();
    if($user = $res->fetch_assoc()){
        if(password_verify($senha,$user['senha_hash'])){
            $_SESSION['usuario'] = $user['id'];
            return true;
        }
    }
    return false;
}

// Atualizar foto
function atualizarFoto($id,$foto){
    global $conn;
    $stmt = $conn->prepare("UPDATE usuarios SET foto=? WHERE id=?");
    $stmt->bind_param("si",$foto,$id);
    return $stmt->execute();
}

// Atualizar preferências
function atualizarPreferencias($id,$idioma,$legendas,$cor_letra){
    global $conn;
    $stmt = $conn->prepare("UPDATE usuarios SET idioma=?,legendas=?,cor_letra=? WHERE id=?");
    $stmt->bind_param("sssi",$idioma,$legendas,$cor_letra,$id);
    return $stmt->execute();
}

// Atualizar dispositivo
function atualizarDispositivo($id,$acao){
    global $conn;
    $novo_estado = ($acao=='desconectar') ? 0 : 1;
    $stmt = $conn->prepare("UPDATE dispositivos SET ativo=? WHERE id=?");
    $stmt->bind_param("ii",$novo_estado,$id);
    if($stmt->execute()) return $novo_estado;
    return false;
}

// Registrar pagamento
function registrarPagamento($usuario_id,$plano_id,$card_number,$card_name,$card_exp,$card_cvv){
    global $conn;
    $stmt = $conn->prepare("INSERT INTO pagamentos (usuario_id,plano_id,card_number,card_name,card_exp,card_cvv) VALUES (?,?,?,?,?,?)");
    if(!$stmt){
        echo json_encode(['success'=>false,'message'=>"Erro prepare SQL: ".$conn->error]);
        exit;
    }
    $stmt->bind_param("iissss",$usuario_id,$plano_id,$card_number,$card_name,$card_exp,$card_cvv);
    if(!$stmt->execute()){
        echo json_encode(['success'=>false,'message'=>"Erro execute SQL: ".$stmt->error]);
        exit;
    }
    return true;
}

// Atualizar plano do usuário
function atualizarPlano($usuario_id,$plano_id){
    global $conn;
    $stmt = $conn->prepare("UPDATE usuarios SET plano_id=? WHERE id=?");
    $stmt->bind_param("ii",$plano_id,$usuario_id);
    return $stmt->execute();
}

// =========================
// Recuperação de senha sem tabela
// =========================

// Enviar código de recuperação
function enviarCodigoRecuperacao($email){
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $res = $stmt->get_result();
    if($user = $res->fetch_assoc()){
        $codigo = rand(100000,999999);
        $_SESSION['recuperacao'][$user['id']] = [
            'codigo' => $codigo,
            'expira' => time() + 600 // 10 minutos de validade
        ];

        // Enviar email (simulado)
        // mail($email, "Recuperação de Senha", "Seu código: $codigo");

        return ['success'=>true,'message'=>"Código enviado para o email cadastrado."];
    }
    return ['success'=>false,'message'=>"Email não cadastrado."];
}

// Validar código
function validarCodigoRecuperacao($codigo){
    if(isset($_SESSION['recuperacao'])){
        foreach($_SESSION['recuperacao'] as $id => $dados){
            if($dados['codigo'] == $codigo){
                if(time() <= $dados['expira']){
                    $_SESSION['usuario'] = $id;
                    unset($_SESSION['recuperacao'][$id]);
                    return ['success'=>true,'message'=>"Código válido!",'redirect'=>'perfil.php'];
                } else {
                    unset($_SESSION['recuperacao'][$id]);
                    return ['success'=>false,'message'=>"Código expirado!"];
                }
            }
        }
    }
    return ['success'=>false,'message'=>"Código inválido!"];
}

// =========================
// Processamento de formulários
// =========================
if(!isset($_POST['tipo_form'])){
    echo json_encode(['success'=>false,'message'=>"Tipo de formulário inválido"]);
    exit;
}

$tipo = $_POST['tipo_form'];

switch($tipo){

    case 'cadastro':
        $nome = $_POST['nome'] ?? '';
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        $confirma = $_POST['confirma_senha'] ?? '';
        $plano_id = $_POST['plano_id'] ?? 1;

        if($senha !== $confirma){
            echo json_encode(['success'=>false,'message'=>"As senhas não coincidem!"]);
            exit;
        }
        if(emailRegistrado($email)){
            echo json_encode(['success'=>false,'message'=>"Este email já está registrado!"]);
            exit;
        }

        $usuario_id = cadastrarUsuario($nome,$email,$senha,$plano_id);
        if($usuario_id){
            $_SESSION['usuario'] = $usuario_id;
            echo json_encode(['success'=>true,'redirect'=>'planos.html']);
        }else{
            echo json_encode(['success'=>false,'message'=>"Erro ao cadastrar usuário."]);
        }
        exit;

    case 'login':
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        if(loginUsuario($email,$senha)){
            echo json_encode(['success'=>true,'redirect'=>'perfil.php']);
        }else{
            echo json_encode(['success'=>false,'message'=>"Email ou senha inválidos!"]);
        }
        exit;

    case 'foto':
        if(isset($_FILES['foto'])){
            $id = $_SESSION['usuario'];
            $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $novoNome = "uploads/foto_".$id.".".$ext;
            if(move_uploaded_file($_FILES['foto']['tmp_name'],$novoNome)){
                atualizarFoto($id,$novoNome);
                echo json_encode(['success'=>true,'foto'=>$novoNome]);
            }else{
                echo json_encode(['success'=>false,'message'=>"Erro ao enviar a foto."]);
            }
        }
        exit;

    case 'preferencias':
        $id = $_SESSION['usuario'];
        $idioma = $_POST['idioma'] ?? 'pt-br';
        $legendas = $_POST['legendas'] ?? 'pt-br';
        $cor_letra = $_POST['cor_letra'] ?? '#ff2e2e';
        atualizarPreferencias($id,$idioma,$legendas,$cor_letra);
        echo json_encode(['success'=>true]);
        exit;

    case 'dispositivo':
        $id = $_POST['id'] ?? 0;
        $acao = $_POST['acao'] ?? '';
        $novo_estado = atualizarDispositivo($id,$acao);
        if($novo_estado!==false){
            echo json_encode(['success'=>true,'novo_estado'=>$novo_estado]);
        }else{
            echo json_encode(['success'=>false,'message'=>"Erro ao atualizar dispositivo"]);
        }
        exit;

    case 'pagamento':
        if(!isset($_SESSION['usuario'])){
            echo json_encode(['success'=>false,'message'=>"Usuário não logado"]);
            exit;
        }
        $usuario_id = $_SESSION['usuario'];
        $plano_id = $_POST['plano_id'] ?? 1;
        $card_number = $_POST['card_number'] ?? '';
        $card_name = $_POST['card_name'] ?? '';
        $card_exp = $_POST['card_exp'] ?? '';
        $card_cvv = $_POST['card_cvv'] ?? '';

        if(registrarPagamento($usuario_id,$plano_id,$card_number,$card_name,$card_exp,$card_cvv)){
            atualizarPlano($usuario_id,$plano_id);
            echo json_encode(['success'=>true,'redirect'=>'perfil.php']);
        }
        exit;

    case 'recuperar':
        $email = $_POST['email'] ?? '';
        $res = enviarCodigoRecuperacao($email);
        echo json_encode($res);
        exit;

    case 'validar_codigo':
        $codigo = $_POST['codigo'] ?? '';
        $res = validarCodigoRecuperacao($codigo);
        echo json_encode($res);
        exit;

    default:
        echo json_encode(['success'=>false,'message'=>"Tipo de formulário inválido"]);
        exit;
}
?>
