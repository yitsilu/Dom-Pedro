// ===== DADOS DOS FILMES =====
const filmesData = [
  {
    id: 'f1', 
    title: 'O Sussurro na Noite', 
    type:'filme', 
    cover:'img/cover1.jpg', 
    trailer:'videos/trailer1.mp4',
    year: 2023,
    duration: '2h 18m',
    genre: ['Terror', 'Suspense'],
    cast: ['Ana Silva', 'Carlos Mendes', 'Marina Oliveira'],
    description: 'Um investigador paranormal é chamado para resolver estranhos eventos em uma mansão antiga, onde sussurros noturnos levam os moradores à loucura.',
    rating: 4.2,
    reviews: [
      { user: 'João Silva', rating: 5, text: 'Filme incrível! Os efeitos sonoros são assustadores.' },
      { user: 'Maria Santos', rating: 4, text: 'Boa atmosfera, mas o final poderia ser melhor.' }
    ]
  },
  {
    id: 'f2', 
    title: 'Casa das Sombras', 
    type:'filme', 
    cover:'img/cover2.jpg', 
    trailer:'videos/trailer2.mp4',
    year: 2022,
    duration: '1h 45m',
    genre: ['Terror', 'Mistério'],
    cast: ['Pedro Costa', 'Julia Rocha', 'Rafael Lima'],
    description: 'Uma família se muda para uma casa isolada e descobre que as sombras nas paredes escondem segredos mortais.',
    rating: 3.8,
    reviews: [
      { user: 'Carlos Oliveira', rating: 4, text: 'Suspense muito bem construído!' }
    ]
  },
  {
    id: 'f3', 
    title: 'Limiar', 
    type:'filme', 
    cover:'img/cover3.jpg', 
    trailer:'videos/trailer3.mp4',
    year: 2024,
    duration: '2h 05m',
    genre: ['Ficção Científica', 'Terror'],
    cast: ['Sofia Almeida', 'Bruno Torres', 'Larissa Santos'],
    description: 'Cientistas descobrem um portal para outra dimensão, mas logo percebem que trouxeram algo terrível de volta.',
    rating: 4.5,
    reviews: []
  },
  {
    id: 'f4', 
    title: 'Ritual', 
    type:'filme', 
    cover:'img/cover4.jpg', 
    trailer:'videos/trailer4.mp4',
    year: 2023,
    duration: '1h 52m',
    genre: ['Terror', 'Folclore'],
    cast: ['André Pereira', 'Camila Nunes', 'Diego Machado'],
    description: 'Um grupo de amigos revive um ritual antigo durante as férias, despertando uma entidade ancestral.',
    rating: 4.0,
    reviews: []
  },
  {
    id: 's1', 
    title: 'Noite Eterna', 
    type:'serie', 
    cover:'img/serie1.jpg', 
    trailer:'videos/serie-trailer1.mp4', 
    temporadas: 3, 
    year: 2022,
    duration: '45m',
    genre: ['Terror', 'Drama'],
    cast: ['Fernanda Costa', 'Ricardo Alves', 'Patrícia Souza'],
    description: 'Em uma cidade onde o sol nunca nasce, os habitantes lutam contra criaturas das trevas e seus próprios demônios internos.',
    rating: 4.3,
    reviews: [
      { user: 'Ana Torres', rating: 5, text: 'Produção impecável! Cada episódio é melhor que o outro.' }
    ]
  },
  {
    id: 's2', 
    title: 'Ecos do Bosque', 
    type:'serie', 
    cover:'img/serie2.jpg', 
    trailer:'videos/serie-trailer2.mp4', 
    temporadas: 2, 
    year: 2021,
    duration: '50m',
    genre: ['Suspense', 'Mistério'],
    cast: ['Lucas Ferreira', 'Isabela Rios', 'Marcos Dias'],
    description: 'Detetives investigam desaparecimentos misteriosos em uma floresta onde os ecos revelam segredos do passado.',
    rating: 4.1,
    reviews: []
  },
  {
    id: 's3', 
    title: 'Sombras da Lua', 
    type:'serie', 
    cover:'img/serie3.jpg', 
    trailer:'videos/serie-trailer3.mp4', 
    temporadas: 1, 
    year: 2023,
    duration: '55m',
    genre: ['Terror', 'Sobrenatural'],
    cast: ['Vanessa Monteiro', 'Gabriel Santos', 'Laura Mendes'],
    description: 'Durante a lua cheia, sombras ganham vida e assombram os moradores de uma pequena comunidade.',
    rating: 4.4,
    reviews: []
  },
  {
    id: 's4', 
    title: 'Noite Sem Fim', 
    type:'serie', 
    cover:'img/serie4.jpg', 
    trailer:'videos/serie-trailer4.mp4', 
    temporadas: 2, 
    year: 2020,
    duration: '48m',
    genre: ['Terror', 'Thriller'],
    cast: ['Roberto Silva', 'Carla Nascimento', 'Felipe Andrade'],
    description: 'Sobreviventes de um apocalipse zumbi enfrentam noites intermináveis em um mundo dominado pelas trevas.',
    rating: 3.9,
    reviews: []
  }
];

// ===== ELEMENTOS =====
const inicioGrid = document.getElementById('inicio-grid');
const filmesGrid = document.getElementById('filmes-grid');
const seriesGrid = document.getElementById('series-grid');
const favoritosGrid = document.getElementById('favoritos-grid');
const searchInput = document.getElementById('search');
const navBtns = document.querySelectorAll('.nav-btn');

// Variáveis para controle dos modais
let currentFavId = null;
let confirmCallback = null;
let currentRating = 0;
let netflixPlayer = null;

// ===== FAVORITOS =====
function getFavs(){ 
  try { 
    return JSON.parse(localStorage.getItem('ds_favs')||'[]'); 
  } catch(e) { 
    return []; 
  } 
}

function saveFavs(arr){ 
  localStorage.setItem('ds_favs', JSON.stringify(arr)); 
}

// ===== MODAL DE CONFIRMAÇÃO =====
function createConfirmModal() {
  let modal = document.getElementById('confirm-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'confirm-modal';
    modal.className = 'confirm-modal hidden';
    document.body.appendChild(modal);
  }
  
  modal.innerHTML = `
    <div class="confirm-content">
      <h3>Remover dos Favoritos</h3>
      <p>Tem certeza que deseja remover este item dos seus favoritos?</p>
      <div class="confirm-buttons">
        <button class="confirm-btn cancel">Cancelar</button>
        <button class="confirm-btn confirm">Remover</button>
      </div>
    </div>
  `;
  
  // Eventos do modal de confirmação
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      hideConfirmModal();
    }
  });

  const cancelBtn = modal.querySelector('.confirm-btn.cancel');
  const confirmBtn = modal.querySelector('.confirm-btn.confirm');
  
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      hideConfirmModal();
    });
  }
  
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      if (confirmCallback && currentFavId) {
        confirmCallback(currentFavId);
      }
      hideConfirmModal();
    });
  }
}

// ===== PLAYER NETFLIX CORRIGIDO =====
class NetflixPlayer {
  constructor() {
    this.currentTime = 0;
    this.duration = 0;
    this.isPlaying = false;
    this.volume = 1;
    this.playbackRate = 1;
    this.currentAudio = 'pt-BR';
    this.currentSubtitle = 'off';
    this.subtitleColor = 'white';
    this.controlsTimeout = null;
    this.controlsVisible = true;
    this.lastMouseMoveTime = Date.now();
    this.init();
  }

  init() {
    this.createPlayerModal();
    this.setupEventListeners();
  }

  createPlayerModal() {
    let modal = document.getElementById('netflix-player');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'netflix-player';
      modal.className = 'video-player-modal hidden';
      document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
      <button class="close-player">✕</button>
      <div class="video-container">
        <video id="main-video"></video>
        <div class="video-loading hidden">Carregando...</div>
        <div class="subtitles"></div>
        
        <div class="player-controls">
          <div class="progress-container">
            <div class="progress-bar">
              <div class="progress-fill"></div>
              <div class="progress-handle"></div>
            </div>
          </div>
          
          <div class="controls-main">
            <button class="control-btn play-pause-btn">▶</button>
            <button class="control-btn skip-backward">⏪</button>
            <button class="control-btn skip-forward">⏩</button>
            
            <div class="volume-control">
              <button class="control-btn volume-btn">🔊</button>
              <input type="range" class="volume-slider" min="0" max="1" step="0.1" value="1">
            </div>
            
            <div class="time-display">
              <span class="current-time">0:00</span> / <span class="duration">0:00</span>
            </div>
            
            <div class="controls-right">
              <button class="control-btn playback-rate-btn">1x</button>
              <button class="control-btn settings-btn" data-menu="audio">🔊</button>
              <button class="control-btn settings-btn" data-menu="subtitles">📝</button>
              <button class="control-btn fullscreen-btn">⛶</button>
            </div>
          </div>
        </div>

        <!-- Menus de configuração FIXOS no container do vídeo -->
        <div class="settings-menu audio-menu hidden">
          <div class="settings-option ${this.currentAudio === 'pt-BR' ? 'active' : ''}" data-action="audio" data-value="pt-BR">Português</div>
          <div class="settings-option ${this.currentAudio === 'en-US' ? 'active' : ''}" data-action="audio" data-value="en-US">English</div>
          <div class="settings-option ${this.currentAudio === 'es-ES' ? 'active' : ''}" data-action="audio" data-value="es-ES">Español</div>
        </div>

        <div class="settings-menu subtitles-menu hidden">
          <div class="settings-option ${this.currentSubtitle === 'off' ? 'active' : ''}" data-action="subtitle" data-value="off">Desativado</div>
          <div class="settings-option ${this.currentSubtitle === 'pt-BR' ? 'active' : ''}" data-action="subtitle" data-value="pt-BR">Português</div>
          <div class="settings-option ${this.currentSubtitle === 'en-US' ? 'active' : ''}" data-action="subtitle" data-value="en-US">English</div>
          <div class="settings-option ${this.currentSubtitle === 'es-ES' ? 'active' : ''}" data-action="subtitle" data-value="es-ES">Español</div>
          <div class="settings-divider"></div>
          <div class="settings-option ${this.subtitleColor === 'white' ? 'active' : ''}" data-action="subtitle-color" data-value="white">🎨 Branco</div>
          <div class="settings-option ${this.subtitleColor === 'yellow' ? 'active' : ''}" data-action="subtitle-color" data-value="yellow">🎨 Amarelo</div>
          <div class="settings-option ${this.subtitleColor === 'green' ? 'active' : ''}" data-action="subtitle-color" data-value="green">🎨 Verde</div>
          <div class="settings-option ${this.subtitleColor === 'cyan' ? 'active' : ''}" data-action="subtitle-color" data-value="cyan">🎨 Ciano</div>
        </div>

        <div class="settings-menu playback-menu hidden">
          <div class="settings-option ${this.playbackRate === 0.5 ? 'active' : ''}" data-action="playback" data-value="0.5">0.5x</div>
          <div class="settings-option ${this.playbackRate === 0.75 ? 'active' : ''}" data-action="playback" data-value="0.75">0.75x</div>
          <div class="settings-option ${this.playbackRate === 1 ? 'active' : ''}" data-action="playback" data-value="1">Normal</div>
          <div class="settings-option ${this.playbackRate === 1.25 ? 'active' : ''}" data-action="playback" data-value="1.25">1.25x</div>
          <div class="settings-option ${this.playbackRate === 1.5 ? 'active' : ''}" data-action="playback" data-value="1.5">1.5x</div>
          <div class="settings-option ${this.playbackRate === 2 ? 'active' : ''}" data-action="playback" data-value="2">2x</div>
        </div>
      </div>
    `;

    this.modal = modal;
    this.video = modal.querySelector('#main-video');
    this.playerControls = modal.querySelector('.player-controls');
    this.setupVideoEvents();
  }

  setupEventListeners() {
    // Botão fechar
    this.modal.querySelector('.close-player').addEventListener('click', () => {
      this.close();
    });

    // Controles de reprodução
    this.modal.querySelector('.play-pause-btn').addEventListener('click', () => {
      this.togglePlay();
      this.showControlsTemporarily();
    });

    // Skip buttons
    this.modal.querySelector('.skip-backward').addEventListener('click', () => {
      this.skip(-10);
      this.showControlsTemporarily();
    });

    this.modal.querySelector('.skip-forward').addEventListener('click', () => {
      this.skip(10);
      this.showControlsTemporarily();
    });

    // Volume
    const volumeSlider = this.modal.querySelector('.volume-slider');
    if (volumeSlider) {
      volumeSlider.addEventListener('input', (e) => {
        this.setVolume(e.target.value);
        this.showControlsTemporarily();
      });
    }

    // Barra de progresso
    const progressContainer = this.modal.querySelector('.progress-container');
    if (progressContainer) {
      progressContainer.addEventListener('click', (e) => {
        const rect = progressContainer.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        this.seek(percent);
        this.showControlsTemporarily();
      });
    }

    // Botões de configuração - CORRIGIDO
    this.modal.querySelectorAll('.settings-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const menuType = btn.dataset.menu;
        this.toggleSettingsMenu(menuType);
        this.showControlsTemporarily();
      });
    });

    // Velocidade de reprodução
    const playbackBtn = this.modal.querySelector('.playback-rate-btn');
    if (playbackBtn) {
      playbackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.toggleSettingsMenu('playback');
        this.showControlsTemporarily();
      });
    }

    // Opções dos menus - CORRIGIDO
    this.modal.addEventListener('click', (e) => {
      const option = e.target.closest('.settings-option');
      if (option) {
        e.stopPropagation();
        const action = option.dataset.action;
        const value = option.dataset.value;
        this.handleSettingsAction(action, value, option);
      }
    });

    // Fullscreen
    const fullscreenBtn = this.modal.querySelector('.fullscreen-btn');
    if (fullscreenBtn) {
      fullscreenBtn.addEventListener('click', () => {
        this.toggleFullscreen();
        this.showControlsTemporarily();
      });
    }

    // Detecção de movimento do mouse - CORRIGIDO
    this.modal.addEventListener('mousemove', (e) => {
      this.lastMouseMoveTime = Date.now();
      this.showControlsTemporarily();
    });

    // Clicar no vídeo para play/pause
    this.modal.querySelector('.video-container').addEventListener('click', (e) => {
      if (e.target === this.modal.querySelector('.video-container') || e.target === this.video) {
        this.togglePlay();
        this.showControlsTemporarily();
      }
    });

    // Fechar menus ao clicar fora - CORRIGIDO
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.settings-menu') && !e.target.closest('.settings-btn') && !e.target.closest('.playback-rate-btn')) {
        this.closeAllMenus();
      }
    });

    // Teclado
    document.addEventListener('keydown', (e) => {
      if (!this.modal.classList.contains('hidden')) {
        if (e.code === 'Space') {
          e.preventDefault();
          this.togglePlay();
          this.showControlsTemporarily();
        } else if (e.code === 'Escape') {
          this.close();
        }
      }
    });

    // Verificar controles automaticamente
    setInterval(() => {
      this.checkHideControls();
    }, 1000);
  }

  setupVideoEvents() {
    if (!this.video) return;

    this.video.addEventListener('loadedmetadata', () => {
      this.duration = this.video.duration;
      this.updateTimeDisplay();
    });

    this.video.addEventListener('timeupdate', () => {
      this.currentTime = this.video.currentTime;
      this.updateProgress();
      this.updateTimeDisplay();
      this.updateSubtitles();
    });

    this.video.addEventListener('play', () => {
      this.isPlaying = true;
      this.updatePlayButton();
    });

    this.video.addEventListener('pause', () => {
      this.isPlaying = false;
      this.updatePlayButton();
    });

    this.video.addEventListener('waiting', () => {
      this.showLoading();
    });

    this.video.addEventListener('canplay', () => {
      this.hideLoading();
    });
  }

  // ===== SISTEMA DE CONTROLES CORRIGIDO =====
  showControlsTemporarily() {
    this.showControls();
    this.lastMouseMoveTime = Date.now();
  }

  checkHideControls() {
    const timeSinceLastMove = Date.now() - this.lastMouseMoveTime;
    const shouldHide = timeSinceLastMove > 3000 && this.isPlaying && !this.isMenuOpen();
    
    if (shouldHide && this.controlsVisible) {
      this.hideControls();
    }
  }

  isMenuOpen() {
    return this.modal.querySelector('.settings-menu:not(.hidden)') !== null;
  }

  showControls() {
    if (this.playerControls) {
      this.playerControls.style.opacity = '1';
      this.controlsVisible = true;
    }
  }

  hideControls() {
    if (this.playerControls && this.isPlaying) {
      this.playerControls.style.opacity = '0';
      this.controlsVisible = false;
    }
  }

  toggleSettingsMenu(menuType) {
    // Fecha todos os menus primeiro
    this.closeAllMenus();
    
    // Abre o menu solicitado
    const menu = this.modal.querySelector(`.${menuType}-menu`);
    if (menu) {
      menu.classList.remove('hidden');
      
      // Posiciona o menu perto do botão
      const btn = this.modal.querySelector(`[data-menu="${menuType}"]`) || 
                  this.modal.querySelector('.playback-rate-btn');
      if (btn) {
        const rect = btn.getBoundingClientRect();
        const modalRect = this.modal.getBoundingClientRect();
        menu.style.top = `${rect.top - modalRect.top - menu.offsetHeight - 10}px`;
        menu.style.left = `${rect.left - modalRect.left}px`;
      }
    }
  }

  closeAllMenus() {
    const menus = this.modal.querySelectorAll('.settings-menu');
    menus.forEach(menu => {
      menu.classList.add('hidden');
    });
  }

  handleSettingsAction(action, value, element) {
    // Atualiza visual
    const menu = element.closest('.settings-menu');
    if (menu) {
      menu.querySelectorAll('.settings-option').forEach(opt => {
        if (opt.dataset.action === action) {
          opt.classList.remove('active');
        }
      });
    }
    element.classList.add('active');

    // Aplica a configuração
    switch (action) {
      case 'audio':
        this.setAudio(value);
        break;
      case 'subtitle':
        this.setSubtitle(value);
        break;
      case 'subtitle-color':
        this.setSubtitleColor(value);
        break;
      case 'playback':
        this.setPlaybackRate(parseFloat(value));
        break;
    }

    this.closeAllMenus();
    this.showControlsTemporarily();
  }

  setAudio(language) {
    this.currentAudio = language;
    console.log(`Áudio alterado para: ${language}`);
  }

  setSubtitle(language) {
    this.currentSubtitle = language;
    const subtitles = this.modal.querySelector('.subtitles');
    
    if (language === 'off') {
      subtitles.classList.remove('active');
      subtitles.textContent = '';
    } else {
      this.updateSubtitles();
    }
  }

  setSubtitleColor(color) {
    this.subtitleColor = color;
    this.updateSubtitleStyle();
  }

  updateSubtitleStyle() {
    const subtitles = this.modal.querySelector('.subtitles');
    if (!subtitles) return;
    
    subtitles.classList.remove('white', 'yellow', 'green', 'cyan');
    subtitles.classList.add(this.subtitleColor);
  }

  setPlaybackRate(rate) {
    this.playbackRate = rate;
    if (this.video) {
      this.video.playbackRate = rate;
    }
    const playbackBtn = this.modal.querySelector('.playback-rate-btn');
    if (playbackBtn) {
      playbackBtn.textContent = `${rate}x`;
    }
  }

  setVolume(level) {
    this.volume = parseFloat(level);
    if (this.video) {
      this.video.volume = this.volume;
    }
    
    const volumeBtn = this.modal.querySelector('.volume-btn');
    if (volumeBtn) {
      if (this.volume == 0) {
        volumeBtn.textContent = '🔇';
      } else if (this.volume < 0.5) {
        volumeBtn.textContent = '🔈';
      } else {
        volumeBtn.textContent = '🔊';
      }
    }
  }

  togglePlay() {
    if (!this.video) return;
    
    if (this.isPlaying) {
      this.video.pause();
    } else {
      this.video.play().catch(e => {
        console.log('Erro ao reproduzir:', e);
      });
    }
  }

  updatePlayButton() {
    const btn = this.modal.querySelector('.play-pause-btn');
    if (btn) {
      btn.textContent = this.isPlaying ? '⏸' : '▶';
    }
  }

  skip(seconds) {
    if (!this.video) return;
    this.video.currentTime += seconds;
    this.showControlsTemporarily();
  }

  seek(percent) {
    if (!this.video) return;
    this.video.currentTime = this.duration * percent;
    this.showControlsTemporarily();
  }

  updateProgress() {
    const progressFill = this.modal.querySelector('.progress-fill');
    if (progressFill && this.duration > 0) {
      const progress = (this.currentTime / this.duration) * 100;
      progressFill.style.width = `${progress}%`;
    }
  }

  updateTimeDisplay() {
    const currentEl = this.modal.querySelector('.current-time');
    const durationEl = this.modal.querySelector('.duration');
    
    if (currentEl) currentEl.textContent = this.formatTime(this.currentTime);
    if (durationEl) durationEl.textContent = this.formatTime(this.duration);
  }

  formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  updateSubtitles() {
    const subtitles = this.modal.querySelector('.subtitles');
    if (!subtitles || this.currentSubtitle === 'off') {
      subtitles.textContent = '';
      subtitles.classList.remove('active');
      return;
    }

    let subtitleText = '';
    const time = Math.floor(this.currentTime);

    // Legendas em Português
    if (this.currentSubtitle === 'pt-BR') {
      if (time >= 0 && time < 10) subtitleText = "Bem-vindo ao DarkScreen";
      else if (time >= 10 && time < 20) subtitleText = "Assista aos melhores filmes e séries";
      else if (time >= 20 && time < 30) subtitleText = "Uma experiência única de entretenimento";
      else if (time >= 30 && time < 40) subtitleText = "Descubra novos títulos exclusivos";
      else if (time >= 40 && time < 50) subtitleText = "Qualidade premium em cada produção";
      else if (time >= 50 && time < 60) subtitleText = "O futuro do streaming está aqui";
    }
    // Legendas em Inglês
    else if (this.currentSubtitle === 'en-US') {
      if (time >= 0 && time < 10) subtitleText = "Welcome to DarkScreen";
      else if (time >= 10 && time < 20) subtitleText = "Watch the best movies and series";
      else if (time >= 20 && time < 30) subtitleText = "A unique entertainment experience";
      else if (time >= 30 && time < 40) subtitleText = "Discover new exclusive titles";
      else if (time >= 40 && time < 50) subtitleText = "Premium quality in every production";
      else if (time >= 50 && time < 60) subtitleText = "The future of streaming is here";
    }
    // Legendas em Espanhol
    else if (this.currentSubtitle === 'es-ES') {
      if (time >= 0 && time < 10) subtitleText = "Bienvenido a DarkScreen";
      else if (time >= 10 && time < 20) subtitleText = "Mira las mejores películas y series";
      else if (time >= 20 && time < 30) subtitleText = "Una experiencia única de entretenimiento";
      else if (time >= 30 && time < 40) subtitleText = "Descubre nuevos títulos exclusivos";
      else if (time >= 40 && time < 50) subtitleText = "Calidad premium en cada producción";
      else if (time >= 50 && time < 60) subtitleText = "El futuro del streaming está aquí";
    }

    subtitles.textContent = subtitleText;
    
    if (this.currentSubtitle !== 'off' && subtitleText) {
      subtitles.classList.add('active');
      this.updateSubtitleStyle();
    } else {
      subtitles.classList.remove('active');
    }
  }

  showLoading() {
    const loading = this.modal.querySelector('.video-loading');
    if (loading) loading.classList.remove('hidden');
  }

  hideLoading() {
    const loading = this.modal.querySelector('.video-loading');
    if (loading) loading.classList.add('hidden');
  }

  toggleFullscreen() {
    if (!document.fullscreenElement) {
      this.modal.requestFullscreen?.().catch(err => {
        console.log(`Erro ao entrar em fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen?.();
    }
  }

  open(videoSrc, title, episodeInfo = '') {
    if (!this.video) return;
    
    this.video.src = videoSrc;
    
    const titleEl = this.modal.querySelector('.video-title');
    if (titleEl) titleEl.textContent = title;
    
    this.modal.classList.remove('hidden');
    
    // Reset do player
    this.currentTime = 0;
    this.isPlaying = false;
    this.updatePlayButton();
    this.updateProgress();
    this.updateTimeDisplay();
    
    // Mostrar controles
    this.showControls();
    this.lastMouseMoveTime = Date.now();
    
    // Tentar reproduzir
    this.video.play().catch(e => {
      console.log('Erro ao reproduzir vídeo:', e);
      this.isPlaying = false;
      this.updatePlayButton();
    });
  }

  close() {
    if (this.video) {
      this.video.pause();
      this.video.src = '';
    }
    if (this.modal) {
      this.modal.classList.add('hidden');
    }
    this.closeAllMenus();
    
    if (this.controlsTimeout) {
      clearTimeout(this.controlsTimeout);
    }
  }
}

// ===== FUNÇÕES DOS MODAIS =====
function showConfirmModal(itemId, itemTitle, callback) {
  currentFavId = itemId;
  confirmCallback = callback;
  
  const confirmModal = document.getElementById('confirm-modal');
  if (!confirmModal) return;
  
  const confirmContent = confirmModal.querySelector('.confirm-content');
  if (confirmContent) {
    confirmContent.querySelector('p').textContent = `Tem certeza que deseja remover "${itemTitle}" dos seus favoritos?`;
  }
  
  confirmModal.classList.remove('hidden');
}

function hideConfirmModal() {
  const confirmModal = document.getElementById('confirm-modal');
  if (confirmModal) {
    confirmModal.classList.add('hidden');
  }
  currentFavId = null;
  confirmCallback = null;
}

// ===== SISTEMA DE INFORMAÇÕES =====
function showInfoModal(item) {
  let modal = document.getElementById('info-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'info-modal';
    modal.className = 'info-modal hidden';
    document.body.appendChild(modal);
  }
  
  modal.innerHTML = `
    <div class="info-content">
      <button class="close-info">✕</button>
      <div class="info-header">
        <div class="info-poster">
          <img src="${item.cover}" alt="${item.title}" onerror="this.src='https://via.placeholder.com/250x350/041200/ffffff?text=Imagem+Não+Encontrada'">
        </div>
        <div class="info-details">
          <h2>${item.title}</h2>
          <div class="info-meta">
            <span>${item.year}</span>
            <span>${item.duration}</span>
            ${item.type === 'serie' ? `<span>${item.temporadas} Temporada${item.temporadas > 1 ? 's' : ''}</span>` : ''}
          </div>
          <div class="info-rating">
            <div class="stars">
              ${Array.from({length: 5}, (_, i) => 
                `<span class="star ${i < Math.floor(item.rating) ? 'active' : ''}">★</span>`
              ).join('')}
            </div>
            <span class="rating-value">${item.rating.toFixed(1)}</span>
          </div>
          <div class="info-description">${item.description}</div>
          <div class="info-cast">
            <h4>Elenco Principal</h4>
            <div class="cast-list">${item.cast.map(actor => 
              `<span style="background: rgba(0,102,51,0.3); padding: 4px 8px; border-radius: 4px; margin: 2px; display: inline-block;">${actor}</span>`
            ).join('')}</div>
          </div>
          <div class="info-genres">
            <h4>Gêneros</h4>
            <div class="genres-list">${item.genre.map(genre => 
              `<span style="background: rgba(0,102,51,0.3); padding: 4px 8px; border-radius: 4px; margin: 2px; display: inline-block;">${genre}</span>`
            ).join('')}</div>
          </div>
        </div>
      </div>
      <div class="info-body">
        <div class="reviews-section">
          <h3>Avaliações e Resenhas</h3>
          <div class="review-form">
            <textarea placeholder="Escreva sua resenha..."></textarea>
            <div class="review-rating-input">
              <span>Avaliação: </span>
              <div class="stars user-stars">
                <span class="star" data-rating="1">★</span>
                <span class="star" data-rating="2">★</span>
                <span class="star" data-rating="3">★</span>
                <span class="star" data-rating="4">★</span>
                <span class="star" data-rating="5">★</span>
              </div>
            </div>
            <button class="submit-review">Enviar Resenha</button>
          </div>
          <div class="reviews-list"></div>
        </div>
      </div>
    </div>
  `;

  // Reviews existentes
  const reviewsList = modal.querySelector('.reviews-list');
  if (reviewsList) {
    renderReviews(item.reviews, reviewsList);
  }

  // Configura o formulário de review
  setupReviewForm(item, modal);

  modal.classList.remove('hidden');

  // Eventos do modal
  const closeBtn = modal.querySelector('.close-info');
  if (closeBtn) {
    closeBtn.addEventListener('click', hideInfoModal);
  }
  
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      hideInfoModal();
    }
  });
}

function setupReviewForm(item, modal) {
  const reviewTextarea = modal.querySelector('.review-form textarea');
  const userStars = modal.querySelectorAll('.user-stars .star');
  const submitButton = modal.querySelector('.submit-review');
  const reviewsList = modal.querySelector('.reviews-list');
  const ratingValue = modal.querySelector('.rating-value');
  const stars = modal.querySelectorAll('.info-rating .star');
  
  if (!reviewTextarea || !submitButton) return;
  
  // Reset do formulário
  currentRating = 0;
  reviewTextarea.value = '';
  userStars.forEach(star => star.classList.remove('active'));
  submitButton.disabled = true;
  
  // Eventos das estrelas
  userStars.forEach(star => {
    star.addEventListener('click', () => {
      const rating = parseInt(star.dataset.rating);
      currentRating = rating;
      
      // Atualiza visual das estrelas
      userStars.forEach((s, index) => {
        s.classList.toggle('active', index < rating);
      });
      
      // Habilita o botão se tiver texto
      submitButton.disabled = !reviewTextarea.value.trim();
    });
  });
  
  // Evento do textarea
  reviewTextarea.addEventListener('input', () => {
    submitButton.disabled = !reviewTextarea.value.trim() || currentRating === 0;
  });
  
  // Evento do botão enviar
  submitButton.addEventListener('click', () => {
    const reviewText = reviewTextarea.value.trim();
    
    if (reviewText && currentRating > 0) {
      // Cria nova review
      const newReview = {
        user: 'Você',
        rating: currentRating,
        text: reviewText,
        date: new Date().toLocaleDateString('pt-BR')
      };
      
      // Adiciona à lista de reviews do item
      if (!item.reviews) item.reviews = [];
      item.reviews.unshift(newReview);
      
      // Atualiza a lista visual
      if (reviewsList) {
        renderReviews(item.reviews, reviewsList);
      }
      
      // Atualiza rating médio
      if (ratingValue && stars) {
        updateItemRating(item, ratingValue, stars);
      }
      
      // Reseta o formulário
      reviewTextarea.value = '';
      currentRating = 0;
      userStars.forEach(star => star.classList.remove('active'));
      submitButton.disabled = true;
      
      // Feedback visual
      showReviewSuccess(submitButton);
      
      // Salva no localStorage
      saveItemData(item);
    }
  });
}

function updateItemRating(item, ratingValue, stars) {
  if (item.reviews && item.reviews.length > 0) {
    const totalRating = item.reviews.reduce((sum, review) => sum + review.rating, 0);
    item.rating = totalRating / item.reviews.length;
    
    // Atualiza estrelas
    stars.forEach((star, index) => {
      star.classList.toggle('active', index < Math.floor(item.rating));
    });
    
    ratingValue.textContent = item.rating.toFixed(1);
  }
}

function renderReviews(reviews, container) {
  if (!container) return;
  
  if (!reviews || reviews.length === 0) {
    container.innerHTML = '<div class="no-reviews">Nenhuma resenha ainda. Seja o primeiro a avaliar!</div>';
    return;
  }
  
  container.innerHTML = reviews.map(review => `
    <div class="review-item">
      <div class="review-header">
        <span class="review-user">${review.user}</span>
        <div>
          <span class="review-rating">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</span>
          ${review.date ? `<span style="color: #888; font-size: 0.8rem; margin-left: 10px;">${review.date}</span>` : ''}
        </div>
      </div>
      <div class="review-text">${review.text}</div>
    </div>
  `).join('');
}

function showReviewSuccess(submitButton) {
  const originalText = submitButton.textContent;
  
  submitButton.textContent = '✓ Avaliação Enviada!';
  submitButton.style.background = '#00aa44';
  
  setTimeout(() => {
    submitButton.textContent = originalText;
    submitButton.style.background = '';
  }, 2000);
}

function saveItemData(item) {
  try {
    const savedItems = JSON.parse(localStorage.getItem('ds_items_data') || '{}');
    savedItems[item.id] = item;
    localStorage.setItem('ds_items_data', JSON.stringify(savedItems));
  } catch (e) {
    console.log('Erro ao salvar dados:', e);
  }
}

function loadItemData() {
  try {
    const savedItems = JSON.parse(localStorage.getItem('ds_items_data') || '{}');
    filmesData.forEach(item => {
      if (savedItems[item.id]) {
        if (savedItems[item.id].reviews) {
          item.reviews = savedItems[item.id].reviews;
        }
        if (savedItems[item.id].rating) {
          item.rating = savedItems[item.id].rating;
        }
      }
    });
  } catch (e) {
    console.log('Erro ao carregar dados:', e);
  }
}

function hideInfoModal() {
  const modal = document.getElementById('info-modal');
  if (modal) {
    modal.classList.add('hidden');
  }
}

// ===== CRIA CARD =====
function createCard(item){
  const isFavorited = getFavs().includes(item.id);
  const card = document.createElement('div'); 
  card.className = 'card'; 
  card.dataset.id = item.id;
  card.innerHTML = `
    <img src="${item.cover}" alt="${item.title}" onerror="this.src='https://via.placeholder.com/260x360/041200/ffffff?text=Imagem+Não+Encontrada'">
    <h3>${item.title}</h3>
    <div class="meta">${item.type==='filme'?'Filme':'Série'}</div>
    <div class="actions">
      <button class="btn btn-fav ${isFavorited ? 'favorited' : ''}" 
              data-id="${item.id}" 
              data-tooltip="${isFavorited ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}">
        ${isFavorited ? '✓' : '♡'}
      </button>
      <button class="btn primary btn-trailer" 
              data-trailer="${item.trailer}" 
              data-tooltip="Assistir">
        ▶
      </button>
      <button class="btn info btn-info" 
              data-id="${item.id}"
              data-tooltip="Mais Informações">
        ⓘ
      </button>
    </div>
  `;
  return card;
}

// ===== RENDERIZA TODOS OS CARDS =====
function renderAll(){
  console.log('Renderizando cards...');
  console.log('Total de itens:', filmesData.length);
  console.log('Filmes:', filmesData.filter(item => item.type === 'filme').length);
  console.log('Séries:', filmesData.filter(item => item.type === 'serie').length);
  
  // Limpa os grids
  if (inicioGrid) inicioGrid.innerHTML = ''; 
  if (filmesGrid) filmesGrid.innerHTML = ''; 
  if (seriesGrid) seriesGrid.innerHTML = ''; 
  if (favoritosGrid) favoritosGrid.innerHTML = '';
  
  const favs = getFavs();
  console.log('Favoritos:', favs);
  
  // Renderiza na seção Início - TODOS OS 8 CARDS
  filmesData.forEach(item => {
    const card = createCard(item);
    if (inicioGrid) inicioGrid.appendChild(card);
  });
  
  // Renderiza na seção Filmes - APENAS 4 FILMES
  const filmes = filmesData.filter(item => item.type === 'filme');
  filmes.forEach(item => {
    const card = createCard(item);
    if (filmesGrid) filmesGrid.appendChild(card);
  });
  
  // Renderiza na seção Séries - APENAS 4 SÉRIES
  const series = filmesData.filter(item => item.type === 'serie');
  series.forEach(item => {
    const card = createCard(item);
    if (seriesGrid) seriesGrid.appendChild(card);
  });
  
  // Renderiza na seção Favoritos
  favs.forEach(id => {
    const item = filmesData.find(x => x.id === id);
    if(item) {
      const card = createCard(item);
      if (favoritosGrid) favoritosGrid.appendChild(card);
    }
  });
  
  console.log('Renderização concluída!');
  
  // Adiciona setas de navegação para os grids
  addGridArrows();
}

// ===== EVENTOS DE CLIQUE =====
document.addEventListener('click', (e) => {
  // Favoritar/Desfavoritar
  if(e.target.classList.contains('btn-fav')){
    const id = e.target.dataset.id;
    const item = filmesData.find(x => x.id === id);
    let favs = getFavs();
    
    if(favs.includes(id)){
      // REMOVER dos favoritos
      showConfirmModal(id, item.title, (itemId) => {
        favs = favs.filter(x => x !== itemId);
        saveFavs(favs);
        renderAll();
      });
    } else { 
      // ADICIONAR aos favoritos
      favs.push(id); 
      saveFavs(favs);
      renderAll();
    }
  }
  
  // Assistir - Player Netflix
  if(e.target.classList.contains('btn-trailer')){
    const src = e.target.dataset.trailer; 
    
    if (!netflixPlayer) {
      netflixPlayer = new NetflixPlayer();
    }
    
    const card = e.target.closest('.card');
    const title = card.querySelector('h3').textContent;
    const type = card.querySelector('.meta').textContent;
    
    netflixPlayer.open(src, title, type);
  }
  
  // Mais informações
  if(e.target.classList.contains('btn-info')){
    const id = e.target.dataset.id;
    console.log('Abrindo informações para ID:', id);
    const item = filmesData.find(x => x.id === id);
    if(item) {
      showInfoModal(item);
    }
  }
});

// ===== PESQUISA =====
searchInput.addEventListener('input', () => {
  const query = searchInput.value.trim().toLowerCase();
  
  document.querySelectorAll('.content-section:not(.hidden) .grid .card').forEach(card => {
    const title = card.querySelector('h3').textContent.toLowerCase();
    card.style.display = !query || title.includes(query) ? 'flex' : 'none';
  });
});

// ===== NAVEGAÇÃO =====
navBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    navBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const target = btn.dataset.target;
    document.querySelectorAll('.content-section').forEach(sec => sec.classList.add('hidden'));
    const targetSection = document.getElementById(target);
    if (targetSection) {
      targetSection.classList.remove('hidden');
    }
    
    const currentQuery = searchInput.value.trim().toLowerCase();
    if(currentQuery) {
      searchInput.dispatchEvent(new Event('input'));
    }
  });
});

// ===== CARROSSEL =====
const slides = document.querySelectorAll('.slide'); 
let currentSlide = 0;

function goToSlide(index){
  slides[currentSlide].classList.remove('active'); 
  currentSlide = (index + slides.length) % slides.length; 
  slides[currentSlide].classList.add('active'); 
}

let carouselInterval = setInterval(() => goToSlide(currentSlide + 1), 3000);

const carousel = document.querySelector('.carousel');
if (carousel) {
  carousel.addEventListener('mouseenter', () => {
    clearInterval(carouselInterval);
  });

  carousel.addEventListener('mouseleave', () => {
    carouselInterval = setInterval(() => goToSlide(currentSlide + 1), 3000);
  });
}

// ===== SETAS HORIZONTAL ESTILO NETFLIX =====
function addGridArrows() {
  const gridsWrapper = document.querySelectorAll('.grid-wrapper');
  
  gridsWrapper.forEach(wrapper => {
    const existingArrows = wrapper.querySelectorAll('.grid-arrow');
    existingArrows.forEach(arrow => arrow.remove());
    
    const grid = wrapper.querySelector('.grid');
    if (!grid) return;
    
    if (grid.scrollWidth > grid.clientWidth) {
      const leftArrow = document.createElement('button');
      leftArrow.className = 'grid-arrow left';
      leftArrow.innerHTML = '‹';
      leftArrow.setAttribute('aria-label', 'Rolar para esquerda');
      
      const rightArrow = document.createElement('button');
      rightArrow.className = 'grid-arrow right';
      rightArrow.innerHTML = '›';
      rightArrow.setAttribute('aria-label', 'Rolar para direita');
      
      wrapper.appendChild(leftArrow);
      wrapper.appendChild(rightArrow);
      
      leftArrow.addEventListener('click', () => { 
        grid.scrollBy({ left: -300, behavior: 'smooth' }); 
      });
      
      rightArrow.addEventListener('click', () => { 
        grid.scrollBy({ left: 300, behavior: 'smooth' }); 
      });
      
      const updateArrowVisibility = () => {
        const scrollLeft = grid.scrollLeft;
        const maxScrollLeft = grid.scrollWidth - grid.clientWidth;
        
        leftArrow.style.opacity = scrollLeft > 0 ? '1' : '0.3';
        rightArrow.style.opacity = scrollLeft < maxScrollLeft ? '1' : '0.3';
      };
      
      grid.addEventListener('scroll', updateArrowVisibility);
      updateArrowVisibility();
    }
  });
}

// ===== INICIALIZAÇÃO =====
document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 DarkScreen Inicializado');
  
  // Inicializa modais
  createConfirmModal();
  
  // Carrega dados salvos
  loadItemData();
  
  // Renderiza a interface
  renderAll();
  
  // Adiciona setas aos grids
  addGridArrows();
  
  // Atualiza setas quando a janela é redimensionada
  window.addEventListener('resize', () => {
    setTimeout(addGridArrows, 100);
  });
});