$(function(){

// Navigation between sections
$('.sidebar a[data-section]').click(function(e){
    e.preventDefault();
    const target = $(this).data('section');
    $('.sidebar a').removeClass('active');
    $(this).addClass('active');
    $('.section').removeClass('active');
    $('#' + target).addClass('active');
});

// Photo selection modal
let selectedPhoto = '';

// Open photo modal
function openPhotoModal() {
    selectedPhoto = $('#profile-icon').attr('src');
    
    // Reset selections
    $('.photo-option').removeClass('selected');
    
    // Mark current photo as selected
    $('.photo-option').each(function() {
        if($(this).data('src') === selectedPhoto) {
            $(this).addClass('selected');
        }
    });
    
    // Show modal
    $('#photo-modal').css('display', 'block');
    setTimeout(() => {
        $('#photo-modal').addClass('show');
        $('.modal-content').addClass('show');
    }, 10);
}

// Close photo modal
function closePhotoModal() {
    $('#photo-modal').removeClass('show');
    $('.modal-content').removeClass('show');
    setTimeout(() => {
        $('#photo-modal').css('display', 'none');
    }, 300);
}

// Photo selection
$(document).on('click', '.photo-option', function() {
    $('.photo-option').removeClass('selected');
    $(this).addClass('selected');
    selectedPhoto = $(this).data('src');
});

// Confirm photo selection
$(document).on('click', '#confirm-photo', function() {
    if(selectedPhoto) {
        // Update photo visually
        $('#profile-icon').attr('src', selectedPhoto);
        
        // Save to database via AJAX
        $.ajax({
            url: window.location.href,
            type: 'POST',
            data: {
                tipo_form: 'atualizar_foto',
                foto_url: selectedPhoto
            },
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    showNotification('Foto de perfil atualizada com sucesso!', 'success');
                } else {
                    showNotification('Erro ao salvar foto: ' + response.message, 'error');
                }
            },
            error: function() {
                showNotification('Erro de conexão ao salvar foto.', 'error');
            }
        });
    } else {
        showNotification('Por favor, selecione uma foto.', 'error');
    }
    closePhotoModal();
});

// Modal controls
$(document).on('click', '.close-modal, #cancel-photo', function() {
    closePhotoModal();
});

// Close modal when clicking outside
$(document).on('click', function(e) {
    if($(e.target).hasClass('modal')) {
        closePhotoModal();
    }
});

// Open modal when clicking on photo
$(document).on('click', '#profile-image-container, .upload-overlay', function() {
    openPhotoModal();
});

// Update user
$('#usuario-form').submit(function(e){
    e.preventDefault();
    
    const formData = $(this).serialize() + '&tipo_form=atualizar_usuario';
    
    $.ajax({
        url: window.location.href,
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function(response) {
            if(response.success) {
                showNotification('Dados atualizados com sucesso!', 'success');
            } else {
                showNotification('Erro ao atualizar dados: ' + response.message, 'error');
            }
        },
        error: function() {
            showNotification('Erro de conexão ao atualizar dados.', 'error');
        }
    });
});

// Save notifications
$('#notificacoes-form').submit(function(e){
    e.preventDefault();
    showNotification('Configurações de notificação salvas!', 'success');
});

// Device connect/disconnect
$('.btn-device').click(function(){
    const btn = $(this);
    const id = btn.data('id');
    const isActive = btn.data('ativo') == 1;
    const card = btn.closest('.device-card');
    
    // Simulate API call
    setTimeout(() => {
        if(isActive) {
            // Disconnect
            btn.text('Conectar')
               .removeClass('btn-danger')
               .addClass('btn-success')
               .data('ativo', 0);
            card.removeClass('active').addClass('inactive');
            card.find('.status-indicator').removeClass('online').addClass('offline');
            card.find('.status-text').text('Offline');
            showNotification('Dispositivo desconectado!', 'success');
        } else {
            // Connect
            btn.text('Desconectar')
               .removeClass('btn-success')
               .addClass('btn-danger')
               .data('ativo', 1);
            card.removeClass('inactive').addClass('active');
            card.find('.status-indicator').removeClass('offline').addClass('online');
            card.find('.status-text').text('Online');
            card.find('.device-last-access').text('Último acesso: ' + new Date().toLocaleString('pt-BR'));
            showNotification('Dispositivo conectado!', 'success');
        }
        
        updateDeviceStats();
    }, 500);
});

// Disconnect all devices
$('#disconnect-all').click(function(){
    if(confirm('Desconectar todos os dispositivos?')) {
        $('.btn-device.btn-danger').each(function(){
            $(this).click();
        });
    }
});

// Add new device
$('#add-device').click(function(){
    showNotification('Funcionalidade em desenvolvimento', 'info');
});

// Generate API key
$('#generate-api-key').click(function(){
    const newApiKey = 'dsk_' + Math.random().toString(36).substr(2, 16);
    $('#api-key').val(newApiKey);
    showNotification('Chave API gerada!', 'success');
});

// Save advanced settings
$('#avancadas-form').submit(function(e){
    e.preventDefault();
    showNotification('Configurações salvas!', 'success');
});

// Update device statistics
function updateDeviceStats() {
    const total = $('.device-card').length;
    const active = $('.device-card.active').length;
    const inactive = $('.device-card.inactive').length;
    
    $('.stat-card:nth-child(1) .stat-number').text(total);
    $('.stat-card:nth-child(2) .stat-number').text(active);
    $('.stat-card:nth-child(3) .stat-number').text(inactive);
}

// Reset notifications
$('#notificacoes-form button[type="reset"]').click(function(){
    if(confirm('Restaurar configurações padrão?')) {
        showNotification('Configurações restauradas', 'success');
    }
});

// Reset advanced settings
$('#avancadas-form button[type="reset"]').click(function(){
    if(confirm('Restaurar configurações padrão?')) {
        showNotification('Configurações restauradas', 'success');
    }
});

// Notification system
function showNotification(message, type = 'info') {
    const notification = $(`
        <div class="notification notification-${type}">
            <div class="notification-content">
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        </div>
    `);
    
    $('body').append(notification);
    
    setTimeout(() => notification.addClass('show'), 100);
    
    notification.find('.notification-close').click(function() {
        notification.removeClass('show');
        setTimeout(() => notification.remove(), 300);
    });
    
    setTimeout(() => {
        if(notification.is(':visible')) {
            notification.removeClass('show');
            setTimeout(() => notification.remove(), 300);
        }
    }, 4000);
}

// Initialize statistics
updateDeviceStats();

console.log('JavaScript carregado - Modal pronto para uso');

});