// =================== Navegação entre seções ===================
document.querySelectorAll('.sidebar ul li a[data-section]').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const targetSection = link.getAttribute('data-section');

    // Ativa o link selecionado
    document.querySelectorAll('.sidebar ul li a').forEach(a => a.classList.remove('active'));
    link.classList.add('active');

    // Mostra a seção correta
    document.querySelectorAll('.section').forEach(sec => {
      if (sec.id === targetSection) {
        sec.classList.add('active');
      } else {
        sec.classList.remove('active');
      }
    });
  });
});

// =================== Upload e preview do ícone do usuário ===================
const inputFile = document.getElementById('upload-icon');
const profileIcon = document.getElementById('profile-icon');

if (inputFile) {
  inputFile.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = e => {
      profileIcon.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// =================== Validação simples dos formulários ===================
function validateForm(form) {
  let valid = true;

  form.querySelectorAll('input[required], select[required]').forEach(input => {
    const errorEl = input.nextElementSibling;

    if (!input.value.trim()) {
      if (errorEl) errorEl.textContent = 'Este campo é obrigatório';
      valid = false;
    } else if (input.type === 'email') {
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!regex.test(input.value.trim())) {
        if (errorEl) errorEl.textContent = 'E-mail inválido';
        valid = false;
      } else {
        if (errorEl) errorEl.textContent = '';
      }
    } else if (input.type === 'password') {
      if (input.value.trim().length < 6) {
        if (errorEl) errorEl.textContent = 'Senha deve ter ao menos 6 caracteres';
        valid = false;
      } else {
        if (errorEl) errorEl.textContent = '';
      }
    } else {
      if (errorEl) errorEl.textContent = '';
    }
  });

  return valid;
}

// =================== Login, Cadastro e Pagamento via AJAX ===================
document.querySelectorAll('form[data-tipo="login"], form[data-tipo="cadastro"], form[data-tipo="pagamento"]').forEach(form => {
  form.addEventListener('submit', e => {
    e.preventDefault();

    if (!validateForm(form)) return;

    const formData = new FormData(form);
    formData.append('tipo_form', form.getAttribute('data-tipo'));

    fetch('processa_form.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      if (data.success && data.redirect) {
        window.location.href = data.redirect;
      } else if (!data.success) {
        alert(data.message);
      }
    })
    .catch(err => {
      alert('Erro ao processar formulário: ' + err);
    });
  });
});

// =================== Formulários gerais (somente validação) ===================
document.querySelectorAll('form:not([data-tipo="login"]):not([data-tipo="cadastro"]):not([data-tipo="pagamento"])').forEach(form => {
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (validateForm(form)) {
      alert('Formulário enviado com sucesso!');
      form.reset();
    }
  });
});
