<?php
session_start();

// Conexão com MySQL (XAMPP padrão)
$host = "localhost";
$dbname = "darkscreen"; 
$user = "root";
$password = "";
$conn = new mysqli($host, $user, $password, $dbname);

// Verifica conexão
if ($conn->connect_error) {
    die(json_encode(['success'=>false,'message'=>"Erro na conexão com o banco: " . $conn->connect_error]));
}

// Função: verificar se email já existe
function emailRegistrado($email) {
    global $conn;
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Função: cadastrar usuário
function cadastrarUsuario($nome, $email, $senha) {
    global $conn;
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
    $sql = "INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $email, $senha_hash);
    return $stmt->execute();
}

// Função: login
function loginUsuario($email, $senha) {
    global $conn;
    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if (password_verify($senha, $row['senha_hash'])) {
            $_SESSION['usuario'] = $row['nome'];
            return true;
        }
    }
    return false;
}

// Função: enviar código de recuperação
function enviarCodigoEmail($email) {
    $codigo = rand(100000, 999999);
    $_SESSION['codigo'] = $codigo;
    $_SESSION['email'] = $email;
    return true; // simula envio
}

// Função: validar código
function validarCodigo($codigo) {
    return isset($_SESSION['codigo']) && $_SESSION['codigo'] == $codigo;
}

// ======================= PROCESSAMENTO =======================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tipo_form'])) {
    $tipo = $_POST['tipo_form'];
    header("Content-Type: application/json");

    // ===== CADASTRO =====
    if ($tipo === "cadastro") {
        $nome = $_POST['nome'] ?? '';
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        $confirma = $_POST['confirma_senha'] ?? '';

        if ($senha !== $confirma) {
            echo json_encode(['success'=>false,'message'=>"As senhas não coincidem!"]);
            exit;
        }
        if (emailRegistrado($email)) {
            echo json_encode(['success'=>false,'message'=>"Este email já está registrado!"]);
            exit;
        }
        if (cadastrarUsuario($nome, $email, $senha)) {
            echo json_encode(['success'=>true,'redirect'=>'planos.html']);
        } else {
            echo json_encode(['success'=>false,'message'=>"Erro ao cadastrar usuário."]);
        }
        exit;
    }

    // ===== LOGIN =====
    if ($tipo === "login") {
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';

        if (loginUsuario($email, $senha)) {
            echo json_encode(['success'=>true,'redirect'=>'perfil.html']);
        } else {
            echo json_encode(['success'=>false,'message'=>"Email ou senha inválidos!"]);
        }
        exit;
    }

    // ===== RECUPERAR SENHA =====
    if ($tipo === "recuperar") {
        $email = $_POST['email'] ?? '';
        if (!emailRegistrado($email)) {
            echo json_encode(['success'=>false,'message'=>"Este email não está registrado!"]);
            exit;
        }
        if (enviarCodigoEmail($email)) {
            echo json_encode(['success'=>true,'message'=>"Código enviado (simulado)!", 'codigo'=>$_SESSION['codigo']]); // opcional para teste
        } else {
            echo json_encode(['success'=>false,'message'=>"Erro ao enviar código."]);
        }
        exit;
    }

    // ===== VALIDAR CÓDIGO =====
    if ($tipo === "validar_codigo" && isset($_POST['codigo'])) {
        $codigo = $_POST['codigo'];
        if (validarCodigo($codigo)) {
            unset($_SESSION['codigo'], $_SESSION['email']);
            echo json_encode(['success'=>true,'message'=>"Código válido!", 'redirect'=>'perfil.html']);
        } else {
            echo json_encode(['success'=>false,'message'=>"Código inválido!"]);
        }
        exit;
    }
}
?>
