// ===== DADOS =====
const items = [
  {id:"f1", type:"movie", title:"O Chamado Sombrio", description:"Um suspense psicológico que desafia os limites entre realidade e pesadelo.", video:"videos/trailer1.mp4", img:"img/filme1.jpg"},
  {id:"f2", type:"movie", title:"Caos Lunar", description:"A humanidade luta pela sobrevivência quando a Lua perde sua órbita.", video:"videos/trailer2.mp4", img:"img/filme2.jpg"},
  {id:"f3", type:"movie", title:"Noite Eterna", description:"Um drama sombrio ambientado em um mundo sem luz solar.", video:"videos/trailer3.mp4", img:"img/filme3.jpg"},
  {id:"f4", type:"movie", title:"Reflexo Mortal", description:"Um mistério sobrenatural sobre espelhos que mostram o futuro.", video:"videos/trailer4.mp4", img:"img/filme4.jpg"},
  {id:"s1", type:"series", title:"Sombras de Aço", description:"Uma série futurista sobre justiça e corrupção em uma cidade distópica.", video:"videos/trailer5.mp4", img:"img/serie1.jpg"},
  {id:"s2", type:"series", title:"A Última Chama", description:"Num mundo quase extinto, uma mulher busca reascender a esperança.", video:"videos/trailer6.mp4", img:"img/serie2.jpg"},
  {id:"s3", type:"series", title:"Linha do Tempo", description:"Um grupo tenta corrigir falhas temporais antes que o mundo colapse.", video:"videos/trailer7.mp4", img:"img/serie3.jpg"},
  {id:"s4", type:"series", title:"O Código Perdido", description:"Uma trama misteriosa sobre segredos escondidos no ciberespaço.", video:"videos/trailer8.mp4", img:"img/serie4.jpg"}
];

// ===== ELEMENTOS =====
const sections = {
  all: document.getElementById("all-section"),
  movies: document.getElementById("movies-section"),
  series: document.getElementById("series-section"),
  favorites: document.getElementById("favorites-section")
};

const allGrid = document.getElementById("all-cards");
const movieGrid = document.getElementById("movie-cards");
const seriesGrid = document.getElementById("series-cards");
const favoritesGrid = document.getElementById("favorites-cards");

const trailerModal = document.getElementById("trailer-modal");
const trailerVideo = document.getElementById("trailer-video");
const trailerClose = document.getElementById("trailer-close");

const infoModal = document.getElementById("info-modal");
const infoClose = document.getElementById("info-close");
const infoTitle = document.getElementById("info-title");
const infoDesc = document.getElementById("info-desc");
const infoImg = document.getElementById("info-img");
const infoStars = document.getElementById("info-stars");
const infoComentario = document.getElementById("info-comentario");
const infoSalvar = document.getElementById("info-salvar");

const confirmModal = document.getElementById("confirm-modal");
const confirmText = document.getElementById("confirm-text");
const confirmYes = document.getElementById("confirm-yes");
const confirmNo = document.getElementById("confirm-no");

let favorites = JSON.parse(localStorage.getItem("favorites")) || [];
let ratings = JSON.parse(localStorage.getItem("ratings")) || {};

// ===== FUNÇÃO CRIAR CARD =====
function createCard(item) {
  const card = document.createElement("div");
  card.classList.add("card");
  card.dataset.id = item.id;
  card.innerHTML = `
    <img src="${item.img}" alt="${item.title}">
    <div class="overlay">
      <div class="icon play"><span>▶ Assistir</span></div>
      <div class="icon heart"><span>❤ Favoritar</span></div>
      <div class="icon info"><span>ℹ Mais informações</span></div>
    </div>
  `;

  const playBtn = card.querySelector(".play");
  const heartBtn = card.querySelector(".heart");
  const infoBtn = card.querySelector(".info");

  // ===== TRAILER FULLSCREEN =====
  playBtn.addEventListener("click", e=>{
    e.stopPropagation();
    trailerVideo.src = item.video;
    trailerModal.classList.remove("hidden");
    trailerVideo.play();
  });

  // ===== FAVORITOS =====
  function updateHeart(){
    if(favorites.includes(item.id)){
      heartBtn.querySelector("span").textContent = "❤ Favorito";
      heartBtn.style.color = "var(--accent-light)";
    } else {
      heartBtn.querySelector("span").textContent = "❤ Favoritar";
      heartBtn.style.color = "#fff";
    }
  }
  updateHeart();

  heartBtn.addEventListener("click", e=>{
    e.stopPropagation();
    if(favorites.includes(item.id)){
      confirmText.textContent = `Deseja remover "${item.title}" dos favoritos?`;
      confirmModal.classList.remove("hidden");
      confirmYes.onclick = ()=>{
        favorites = favorites.filter(f=>f!==item.id);
        localStorage.setItem("favorites", JSON.stringify(favorites));
        confirmModal.classList.add("hidden");
        renderFavorites();
        updateHeart();
      }
      confirmNo.onclick = ()=>confirmModal.classList.add("hidden");
    } else {
      favorites.push(item.id);
      localStorage.setItem("favorites", JSON.stringify(favorites));
      renderFavorites();
      updateHeart();
    }
  });

  // ===== MAIS INFORMAÇÕES =====
  infoBtn.addEventListener("click", e=>{
    e.stopPropagation();
    infoTitle.textContent = item.title;
    infoDesc.textContent = item.description;
    infoImg.src = item.img;
    renderRating(item.id);
    infoModal.classList.remove("hidden");
    infoSalvar.onclick = ()=>{
      const selected = Array.from(infoStars.querySelectorAll(".star.on")).length;
      ratings[item.id] = { stars: selected, comment: infoComentario.value };
      localStorage.setItem("ratings", JSON.stringify(ratings));
      alert("Avaliação salva!");
    }
  });

  return card;
}

// ===== RENDERIZAÇÃO =====
function renderAll(){
  allGrid.innerHTML=""; movieGrid.innerHTML=""; seriesGrid.innerHTML="";
  items.forEach(item=>{
    const card = createCard(item);
    allGrid.appendChild(card.cloneNode(true));
    if(item.type==="movie") movieGrid.appendChild(card.cloneNode(true));
    if(item.type==="series") seriesGrid.appendChild(card.cloneNode(true));
  });
}

function renderFavorites(){
  favoritesGrid.innerHTML="";
  favorites.forEach(id=>{
    const item = items.find(i=>i.id===id);
    if(item) favoritesGrid.appendChild(createCard(item));
  });
}

// ===== AVALIAÇÃO =====
function renderRating(id){
  infoStars.innerHTML="";
  for(let i=1;i<=5;i++){
    const star = document.createElement("div");
    star.classList.add("star");
    if(ratings[id] && ratings[id].stars>=i) star.classList.add("on");
    star.addEventListener("click", ()=>renderRatingClick(id,i));
    infoStars.appendChild(star);
  }
  infoComentario.value = ratings[id] ? ratings[id].comment : "";
}

function renderRatingClick(id,value){
  Array.from(infoStars.children).forEach((s,index)=>{
    if(index<value) s.classList.add("on"); else s.classList.remove("on");
  });
}

// ===== MODAIS =====
trailerClose.addEventListener("click", ()=>{
  trailerModal.classList.add("hidden");
  trailerVideo.pause();
  trailerVideo.src="";
});

infoClose.addEventListener("click", ()=>infoModal.classList.add("hidden"));

// ===== NAVIGAÇÃO =====
document.querySelectorAll(".nav-btn").forEach(btn=>{
  btn.addEventListener("click", ()=>{
    document.querySelectorAll(".nav-btn").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    Object.values(sections).forEach(s=>s.classList.add("hidden"));
    sections[btn.dataset.section].classList.remove("hidden");
  });
});

// ===== GRID SETAS =====
document.querySelectorAll(".grid-wrapper").forEach(wrapper=>{
  const row = wrapper.querySelector(".grid");
  const left = wrapper.querySelector(".grid-arrow.left");
  const right = wrapper.querySelector(".grid-arrow.right");
  left.addEventListener("click", ()=>row.scrollBy({left:-280, behavior:"smooth"}));
  right.addEventListener("click", ()=>row.scrollBy({left:280, behavior:"smooth"}));
});

// ===== CARROSSEL AUTOMÁTICO =====
let currentSlide = 0;
const slides = document.querySelectorAll(".slide");
function nextSlide(){
  slides.forEach((s,i)=>s.classList.remove("active"));
  slides[currentSlide].classList.add("active");
  currentSlide = (currentSlide+1)%slides.length;
}
if(slides.length>0) setInterval(nextSlide, 4000);

// ===== PESQUISA =====
const searchInput = document.getElementById("search");
searchInput.addEventListener("input", ()=>{
  const query = searchInput.value.toLowerCase();
  items.forEach(item=>{
    const cardEl = document.querySelector(`.card[data-id="${item.id}"]`);
    if(cardEl){
      cardEl.style.display = item.title.toLowerCase().includes(query) ? "flex" : "none";
    }
  });
});

// ===== INICIALIZAÇÃO =====
renderAll(); renderFavorites();
