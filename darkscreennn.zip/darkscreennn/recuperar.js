document.addEventListener("DOMContentLoaded", () => {
  const userInput = document.getElementById("userInput");
  const btnContinuar = document.getElementById("btnContinuar");
  const codigoBox = document.getElementById("codigoBox");
  const codigoInput = document.getElementById("codigo");
  const btnConfirmar = document.getElementById("btnConfirmar");
  const recuperarBox = document.getElementById("recuperarBox");
  const btnRecuperar = document.getElementById("btnRecuperar");

  let codigoGerado = "";

  function gerarCodigo() {
    const caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let codigo = "";
    for (let i = 0; i < 6; i++) {
      codigo += caracteres.charAt(Math.floor(Math.random() * caracteres.length));
    }
    return codigo;
  }

  btnContinuar.addEventListener("click", () => {
    const user = userInput.value.trim();
    if (!user) {
      alert("Digite seu Gmail ou número de telefone!");
      userInput.focus();
      return;
    }

    codigoGerado = gerarCodigo();
    codigoBox.style.display = "block";
    codigoInput.focus();

    let codigoExibir = document.getElementById("codigoExibir");
    if (!codigoExibir) {
      codigoExibir = document.createElement("div");
      codigoExibir.id = "codigoExibir";
      codigoExibir.style.background = "#1a1a1a";
      codigoExibir.style.color = "#9b30ff";
      codigoExibir.style.fontWeight = "bold";
      codigoExibir.style.padding = "12px";
      codigoExibir.style.marginBottom = "10px";
      codigoExibir.style.borderRadius = "8px";
      codigoExibir.style.boxShadow = "0 0 6px rgba(155,48,255,0.6)";
      codigoExibir.style.fontSize = "16px";
      codigoExibir.style.textAlign = "center";

      codigoBox.insertBefore(codigoExibir, codigoInput);
    }
    codigoExibir.textContent = `Código gerado: ${codigoGerado}`;
  });

  btnConfirmar.addEventListener("click", () => {
    const codigo = codigoInput.value.trim();
    if (!codigo) {
      alert("Digite o código para continuar!");
      codigoInput.focus();
      return;
    }
    if (codigo.toUpperCase() === codigoGerado) {
      recuperarBox.style.display = "block";
    } else {
      alert("Código incorreto! Tente novamente.");
      codigoInput.focus();
    }
  });

  btnRecuperar.addEventListener("click", () => {
    alert("Conta recuperada com sucesso!");
    window.location.href = "perfil.html";
  });
});
